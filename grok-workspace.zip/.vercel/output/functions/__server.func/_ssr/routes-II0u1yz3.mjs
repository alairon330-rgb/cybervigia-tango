import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Check, i as Copy, n as Trash2, o as Bookmark, r as ScanSearch, s as ArrowUpRight } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-II0u1yz3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** MD5 em hex minúsculo. Só para o hash público do Gravatar. */
function md5(input) {
	const bytes = new TextEncoder().encode(input);
	const bitLen = bytes.length * 8;
	const padLen = (56 - (bytes.length + 1) % 64 + 64) % 64;
	const total = bytes.length + 1 + padLen + 8;
	const buf = new Uint8Array(total);
	buf.set(bytes);
	buf[bytes.length] = 128;
	const view = new DataView(buf.buffer);
	view.setUint32(total - 8, bitLen >>> 0, true);
	view.setUint32(total - 4, Math.floor(bitLen / 4294967296), true);
	let a0 = 1732584193;
	let b0 = 4023233417;
	let c0 = 2562383102;
	let d0 = 271733878;
	const s = [
		7,
		12,
		17,
		22,
		7,
		12,
		17,
		22,
		7,
		12,
		17,
		22,
		7,
		12,
		17,
		22,
		5,
		9,
		14,
		20,
		5,
		9,
		14,
		20,
		5,
		9,
		14,
		20,
		5,
		9,
		14,
		20,
		4,
		11,
		16,
		23,
		4,
		11,
		16,
		23,
		4,
		11,
		16,
		23,
		4,
		11,
		16,
		23,
		6,
		10,
		15,
		21,
		6,
		10,
		15,
		21,
		6,
		10,
		15,
		21,
		6,
		10,
		15,
		21
	];
	const rot = (x, c) => (x << c | x >>> 32 - c) >>> 0;
	for (let off = 0; off < total; off += 64) {
		const M = /* @__PURE__ */ new Uint32Array(16);
		for (let j = 0; j < 16; j++) M[j] = view.getUint32(off + j * 4, true);
		let A = a0;
		let B = b0;
		let C = c0;
		let D = d0;
		for (let i = 0; i < 64; i++) {
			let F;
			let g;
			if (i < 16) {
				F = B & C | ~B & D;
				g = i;
			} else if (i < 32) {
				F = D & B | ~D & C;
				g = (5 * i + 1) % 16;
			} else if (i < 48) {
				F = B ^ C ^ D;
				g = (3 * i + 5) % 16;
			} else {
				F = C ^ (B | ~D);
				g = 7 * i % 16;
			}
			const K = Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296) >>> 0;
			F = F + A + K + M[g] >>> 0;
			A = D;
			D = C;
			C = B;
			B = B + rot(F, s[i]) >>> 0;
		}
		a0 = a0 + A >>> 0;
		b0 = b0 + B >>> 0;
		c0 = c0 + C >>> 0;
		d0 = d0 + D >>> 0;
	}
	const out = /* @__PURE__ */ new Uint8Array(16);
	const ov = new DataView(out.buffer);
	ov.setUint32(0, a0, true);
	ov.setUint32(4, b0, true);
	ov.setUint32(8, c0, true);
	ov.setUint32(12, d0, true);
	return [...out].map((b) => b.toString(16).padStart(2, "0")).join("");
}
var PROVIDERS = {
	"gmail.com": {
		name: "Google",
		note: "Pontos no nome são ignorados e o texto depois de + é um alias da mesma caixa."
	},
	"googlemail.com": {
		name: "Google",
		note: "É o mesmo Gmail. Pontos e o alias depois de + não criam outra caixa."
	},
	"outlook.com": {
		name: "Microsoft",
		note: "O texto depois de + costuma ser alias da mesma caixa."
	},
	"outlook.com.br": {
		name: "Microsoft",
		note: "O texto depois de + costuma ser alias da mesma caixa."
	},
	"hotmail.com": {
		name: "Microsoft",
		note: "Caixa antiga da Microsoft, hoje no Outlook."
	},
	"hotmail.com.br": {
		name: "Microsoft",
		note: "Caixa antiga da Microsoft, hoje no Outlook."
	},
	"live.com": {
		name: "Microsoft",
		note: null
	},
	"live.com.br": {
		name: "Microsoft",
		note: null
	},
	"msn.com": {
		name: "Microsoft",
		note: null
	},
	"yahoo.com": {
		name: "Yahoo",
		note: "O hífen depois do nome (nome-tag) pode ser um alias."
	},
	"yahoo.com.br": {
		name: "Yahoo",
		note: null
	},
	"ymail.com": {
		name: "Yahoo",
		note: null
	},
	"icloud.com": {
		name: "Apple",
		note: "O texto depois de + pode ser um alias do iCloud."
	},
	"me.com": {
		name: "Apple",
		note: null
	},
	"mac.com": {
		name: "Apple",
		note: null
	},
	"proton.me": {
		name: "Proton",
		note: "Provedor com foco em privacidade, não é e-mail descartável."
	},
	"protonmail.com": {
		name: "Proton",
		note: "Provedor com foco em privacidade, não é e-mail descartável."
	},
	"pm.me": {
		name: "Proton",
		note: null
	},
	"tuta.com": {
		name: "Tuta",
		note: "Provedor com foco em privacidade."
	},
	"tutanota.com": {
		name: "Tuta",
		note: "Provedor com foco em privacidade."
	},
	"aol.com": {
		name: "AOL",
		note: null
	},
	"zoho.com": {
		name: "Zoho",
		note: null
	},
	"gmx.com": {
		name: "GMX",
		note: null
	},
	"fastmail.com": {
		name: "Fastmail",
		note: null
	},
	"hey.com": {
		name: "HEY",
		note: null
	},
	"uol.com.br": {
		name: "UOL",
		note: null
	},
	"bol.com.br": {
		name: "BOL",
		note: null
	},
	"terra.com.br": {
		name: "Terra",
		note: null
	},
	"ig.com.br": {
		name: "iG",
		note: null
	},
	"globo.com": {
		name: "Globo",
		note: null
	},
	"globomail.com": {
		name: "Globo",
		note: null
	},
	"oi.com.br": {
		name: "Oi",
		note: null
	},
	"r7.com": {
		name: "R7",
		note: null
	}
};
var DISPOSABLE = /* @__PURE__ */ new Set([
	"mailinator.com",
	"guerrillamail.com",
	"guerrillamail.org",
	"guerrillamail.net",
	"guerrillamailblock.com",
	"grr.la",
	"sharklasers.com",
	"10minutemail.com",
	"10minutemail.net",
	"tempmail.com",
	"temp-mail.org",
	"temp-mail.io",
	"yopmail.com",
	"yopmail.fr",
	"trashmail.com",
	"trash-mail.com",
	"dispostable.com",
	"maildrop.cc",
	"getnada.com",
	"mohmal.com",
	"emailondeck.com",
	"mintemail.com",
	"mytemp.email",
	"tempr.email",
	"discard.email",
	"mailnesia.com",
	"inboxkitten.com",
	"spamgourmet.com",
	"getairmail.com",
	"dropmail.me",
	"moakt.com",
	"tmpmail.net",
	"tmpmail.org",
	"1secmail.com",
	"1secmail.org",
	"1secmail.net",
	"fakeinbox.com",
	"mailcatch.com",
	"spam4.me",
	"tempinbox.com",
	"burnermail.io",
	"guerrillamail.biz",
	"mailnull.com",
	"trashmail.de",
	"tempmailo.com",
	"generator.email",
	"fakemail.net",
	"throwawaymail.com",
	"mailpoof.com",
	"instant-email.org",
	"emailfake.com",
	"linshi-email.com",
	"mohmal.im",
	"tmpbox.net",
	"tempm.com",
	"discardmail.com",
	"mailexpire.com",
	"spamdecoy.net",
	"gettempmail.com"
]);
var ROLES = /* @__PURE__ */ new Set([
	"admin",
	"administrator",
	"info",
	"contact",
	"contato",
	"suporte",
	"support",
	"sales",
	"vendas",
	"noreply",
	"no-reply",
	"donotreply",
	"postmaster",
	"webmaster",
	"hostmaster",
	"abuse",
	"security",
	"seguranca",
	"billing",
	"financeiro",
	"rh",
	"hr",
	"marketing",
	"newsletter",
	"notificacao",
	"notifications",
	"hello",
	"ola",
	"oi",
	"team",
	"equipe",
	"comercial",
	"atendimento",
	"sac",
	"ouvidoria",
	"imprensa",
	"press",
	"jobs",
	"careers",
	"vagas"
]);
var LOCAL_RE = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+$/;
var DOMAIN_RE = /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$/;
function isDomain(raw) {
	return DOMAIN_RE.test(raw.trim().toLowerCase().replace(/^@/, ""));
}
function analyzeEmail(raw) {
	const email = raw.trim().toLowerCase();
	if (!email) return null;
	const empty = {
		valid: false,
		reason: "Formato irreconhecível.",
		email,
		local: "",
		domain: "",
		provider: null,
		providerNote: null,
		disposable: false,
		role: false,
		kind: "inválido",
		gravatarHash: null,
		alias: null,
		suggestions: []
	};
	const at = email.indexOf("@");
	if (at <= 0 || at !== email.lastIndexOf("@")) return {
		...empty,
		reason: "Precisa de um único @."
	};
	const local = email.slice(0, at);
	const domain = email.slice(at + 1);
	if (!LOCAL_RE.test(local) || local.startsWith(".") || local.endsWith(".") || local.includes("..")) return {
		...empty,
		local,
		domain,
		reason: "A parte antes do @ tem caractere inválido."
	};
	if (!DOMAIN_RE.test(domain)) return {
		...empty,
		local,
		domain,
		reason: "O domínio não parece válido."
	};
	const provider = PROVIDERS[domain] ?? null;
	const disposable = DISPOSABLE.has(domain);
	const base = local.split("+")[0] ?? local;
	const role = ROLES.has(base);
	const alias = local.includes("+") ? local.slice(local.indexOf("+") + 1) : null;
	const kind = disposable ? "descartável" : provider ? "gratuito" : "próprio";
	return {
		valid: true,
		reason: null,
		email,
		local,
		domain,
		provider: provider?.name ?? null,
		providerNote: provider?.note ?? null,
		disposable,
		role,
		kind,
		gravatarHash: md5(email),
		alias,
		suggestions: handleSuggestions(base)
	};
}
function handleSuggestions(base) {
	const clean = base.toLowerCase();
	const noDots = clean.replace(/\./g, "");
	const parts = clean.split(/[._-]+/).filter(Boolean);
	const out = /* @__PURE__ */ new Set();
	if (clean) out.add(clean);
	if (noDots) out.add(noDots);
	const underscored = clean.replace(/[.\s]+/g, "_");
	const dashed = clean.replace(/[._]+/g, "-");
	if (underscored) out.add(underscored);
	if (dashed) out.add(dashed);
	if (parts.length >= 2) {
		const [a, b] = parts;
		if (a && b) {
			out.add(a + b);
			out.add(`${a}_${b}`);
			out.add(`${a}.${b}`);
			out.add(`${a[0] ?? ""}${b}`);
			out.add(`${a}${b[0] ?? ""}`);
		}
	}
	out.delete("");
	return [...out].slice(0, 8);
}
function cleanHandle(raw) {
	return raw.trim().replace(/^@+/, "").replace(/\s+/g, "");
}
function emailPatterns(name, domain) {
	const folded = name.normalize("NFD").replace(/\p{M}/gu, "").toLowerCase().replace(/[^a-z\s]/g, " ").split(/\s+/).filter(Boolean);
	if (folded.length === 0) return [];
	const first = folded[0] ?? "";
	const last = folded[folded.length - 1] ?? "";
	const locals = [first];
	if (folded.length > 1 && first !== last) locals.push(`${first}.${last}`, `${first}${last}`, `${first}_${last}`, `${first[0] ?? ""}${last}`, last);
	const explicit = domain?.trim().replace(/^@/, "").toLowerCase();
	const domains = explicit ? [explicit] : [
		"gmail.com",
		"hotmail.com",
		"outlook.com",
		"uol.com.br"
	];
	const out = [];
	for (const d of domains) {
		if (!DOMAIN_RE.test(d)) continue;
		for (const local of locals) if (local) out.push(`${local}@${d}`);
	}
	return out.slice(0, 24);
}
function q(value) {
	return encodeURIComponent(value);
}
function buildSearches(input) {
	const { email, username, name, domain } = input;
	const items = [];
	if (email) {
		const exact = `"${email}"`;
		items.push({
			group: "E-mail",
			title: "Google — frase exata",
			detail: "Onde esse endereço apareceu em página pública.",
			href: `https://www.google.com/search?q=${q(exact)}`
		}, {
			group: "E-mail",
			title: "Bing",
			detail: "Mesma frase, outro índice.",
			href: `https://www.bing.com/search?q=${q(exact)}`
		}, {
			group: "E-mail",
			title: "DuckDuckGo",
			detail: "Busca sem conta.",
			href: `https://duckduckgo.com/?q=${q(exact)}`
		}, {
			group: "E-mail",
			title: "Have I Been Pwned",
			detail: "Diz se o e-mail surgiu em vazamento conhecido. Não mostra senha.",
			href: `https://haveibeenpwned.com/account/${q(email)}`
		}, {
			group: "E-mail",
			title: "Pastes públicos",
			detail: "Procura o endereço em sites de colagem.",
			href: `https://www.google.com/search?q=${q(`${exact} (site:pastebin.com OR site:rentry.co OR site:ghostbin.com OR site:paste.ee)`)}`
		}, {
			group: "E-mail",
			title: "Código no GitHub",
			detail: "Arquivos públicos que citam o endereço.",
			href: `https://github.com/search?q=${q(exact)}&type=code`
		});
	}
	if (username) {
		const exact = `"${username}"`;
		items.push({
			group: "Usuário",
			title: "Google — usuário",
			detail: "Menções públicas desse @.",
			href: `https://www.google.com/search?q=${q(exact)}`
		}, {
			group: "Usuário",
			title: "Redes no Google",
			detail: "Recorte nas redes mais citadas.",
			href: `https://www.google.com/search?q=${q(`${exact} (instagram OR tiktok OR twitter OR linkedin OR github OR youtube)`)}`
		});
	}
	if (name) {
		const exact = `"${name}"`;
		items.push({
			group: "Nome",
			title: "Nome + e-mail",
			detail: "Páginas que juntam o nome a um endereço.",
			href: `https://www.google.com/search?q=${q(`${exact} (email OR e-mail OR "@")`)}`
		});
		if (domain) items.push({
			group: "Nome",
			title: `Nome no ${domain}`,
			detail: "Menções do nome junto do domínio.",
			href: `https://www.google.com/search?q=${q(`${exact} "@${domain}"`)}`
		});
		else items.push({
			group: "Nome",
			title: "Nome em provedores comuns",
			detail: "Gmail, Outlook, Hotmail e UOL.",
			href: `https://www.google.com/search?q=${q(`${exact} ("@gmail.com" OR "@hotmail.com" OR "@outlook.com" OR "@uol.com.br")`)}`
		});
		items.push({
			group: "Nome",
			title: "LinkedIn público",
			detail: "Perfis indexados. O LinkedIn pede login para ver o resto.",
			href: `https://www.google.com/search?q=${q(`${exact} site:linkedin.com/in`)}`
		});
	}
	if (domain) items.push({
		group: "Domínio",
		title: "crt.sh",
		detail: "Certificados públicos emitidos para o domínio.",
		href: `https://crt.sh/?q=${q(`%.${domain}`)}`
	}, {
		group: "Domínio",
		title: "WHOIS",
		detail: "Registro público: titular, datas e servidores.",
		href: `https://who.is/whois/${encodeURIComponent(domain)}`
	}, {
		group: "Domínio",
		title: "Páginas do domínio",
		detail: "O que o Google indexou nesse host.",
		href: `https://www.google.com/search?q=${q(`site:${domain}`)}`
	});
	return items;
}
var CATEGORIES = [
	"Social",
	"Vídeo",
	"Mensagem",
	"Trabalho",
	"Código",
	"Criação",
	"Áudio",
	"Jogos",
	"Perfil"
];
function userPath(url, handle) {
	if (!handle) return null;
	return url.replace("{u}", encodeURIComponent(handle));
}
function subdomain(handle, root) {
	const safe = handle.toLowerCase().replace(/[^a-z0-9-]/g, "");
	if (!safe) return null;
	return `https://${safe}.${root}`;
}
var SITES = [
	{
		id: "instagram",
		name: "Instagram",
		category: "Social",
		host: "instagram.com",
		build: (h) => userPath("https://www.instagram.com/{u}/", h)
	},
	{
		id: "facebook",
		name: "Facebook",
		category: "Social",
		host: "facebook.com",
		build: (h) => userPath("https://www.facebook.com/{u}", h)
	},
	{
		id: "x",
		name: "X",
		category: "Social",
		host: "x.com",
		build: (h) => userPath("https://x.com/{u}", h)
	},
	{
		id: "tiktok",
		name: "TikTok",
		category: "Social",
		host: "tiktok.com",
		build: (h) => userPath("https://www.tiktok.com/@{u}", h)
	},
	{
		id: "threads",
		name: "Threads",
		category: "Social",
		host: "threads.net",
		build: (h) => userPath("https://www.threads.net/@{u}", h)
	},
	{
		id: "kwai",
		name: "Kwai",
		category: "Social",
		host: "kwai.com",
		hint: "O link público do Kwai muda de vez em quando.",
		build: (h) => userPath("https://www.kwai.com/@{u}", h)
	},
	{
		id: "pinterest",
		name: "Pinterest",
		category: "Social",
		host: "pinterest.com",
		build: (h) => userPath("https://www.pinterest.com/{u}/", h)
	},
	{
		id: "reddit",
		name: "Reddit",
		category: "Social",
		host: "reddit.com",
		build: (h) => userPath("https://www.reddit.com/user/{u}", h)
	},
	{
		id: "snapchat",
		name: "Snapchat",
		category: "Social",
		host: "snapchat.com",
		build: (h) => userPath("https://www.snapchat.com/add/{u}", h)
	},
	{
		id: "tumblr",
		name: "Tumblr",
		category: "Social",
		host: "tumblr.com",
		hint: "Vira subdomínio. Pontos e símbolos saem.",
		build: (h) => subdomain(h, "tumblr.com")
	},
	{
		id: "bluesky",
		name: "Bluesky",
		category: "Social",
		host: "bsky.app",
		hint: "Sem ponto no nome, completa com .bsky.social.",
		build: (h) => {
			if (!h) return null;
			const handle = h.includes(".") ? h : `${h}.bsky.social`;
			return `https://bsky.app/profile/${encodeURIComponent(handle)}`;
		}
	},
	{
		id: "mastodon",
		name: "Mastodon",
		category: "Social",
		host: "mastodon.social",
		hint: "Só a instância mastodon.social. Outras pedem o endereço completo.",
		build: (h) => userPath("https://mastodon.social/@{u}", h)
	},
	{
		id: "vk",
		name: "VK",
		category: "Social",
		host: "vk.com",
		build: (h) => userPath("https://vk.com/{u}", h)
	},
	{
		id: "quora",
		name: "Quora",
		category: "Social",
		host: "quora.com",
		build: (h) => userPath("https://www.quora.com/profile/{u}", h)
	},
	{
		id: "youtube",
		name: "YouTube",
		category: "Vídeo",
		host: "youtube.com",
		build: (h) => userPath("https://www.youtube.com/@{u}", h)
	},
	{
		id: "twitch",
		name: "Twitch",
		category: "Vídeo",
		host: "twitch.tv",
		build: (h) => userPath("https://www.twitch.tv/{u}", h)
	},
	{
		id: "kick",
		name: "Kick",
		category: "Vídeo",
		host: "kick.com",
		build: (h) => userPath("https://kick.com/{u}", h)
	},
	{
		id: "vimeo",
		name: "Vimeo",
		category: "Vídeo",
		host: "vimeo.com",
		build: (h) => userPath("https://vimeo.com/{u}", h)
	},
	{
		id: "telegram",
		name: "Telegram",
		category: "Mensagem",
		host: "t.me",
		build: (h) => userPath("https://t.me/{u}", h)
	},
	{
		id: "linkedin",
		name: "LinkedIn",
		category: "Trabalho",
		host: "linkedin.com",
		build: (h) => userPath("https://www.linkedin.com/in/{u}", h)
	},
	{
		id: "github",
		name: "GitHub",
		category: "Código",
		host: "github.com",
		build: (h) => userPath("https://github.com/{u}", h)
	},
	{
		id: "gitlab",
		name: "GitLab",
		category: "Código",
		host: "gitlab.com",
		build: (h) => userPath("https://gitlab.com/{u}", h)
	},
	{
		id: "codepen",
		name: "CodePen",
		category: "Código",
		host: "codepen.io",
		build: (h) => userPath("https://codepen.io/{u}", h)
	},
	{
		id: "replit",
		name: "Replit",
		category: "Código",
		host: "replit.com",
		build: (h) => userPath("https://replit.com/@{u}", h)
	},
	{
		id: "devto",
		name: "Dev.to",
		category: "Código",
		host: "dev.to",
		build: (h) => userPath("https://dev.to/{u}", h)
	},
	{
		id: "hackernews",
		name: "Hacker News",
		category: "Código",
		host: "news.ycombinator.com",
		build: (h) => userPath("https://news.ycombinator.com/user?id={u}", h)
	},
	{
		id: "npm",
		name: "npm",
		category: "Código",
		host: "npmjs.com",
		build: (h) => userPath("https://www.npmjs.com/~{u}", h)
	},
	{
		id: "leetcode",
		name: "LeetCode",
		category: "Código",
		host: "leetcode.com",
		build: (h) => userPath("https://leetcode.com/u/{u}", h)
	},
	{
		id: "huggingface",
		name: "Hugging Face",
		category: "Código",
		host: "huggingface.co",
		build: (h) => userPath("https://huggingface.co/{u}", h)
	},
	{
		id: "pastebin",
		name: "Pastebin",
		category: "Código",
		host: "pastebin.com",
		build: (h) => userPath("https://pastebin.com/u/{u}", h)
	},
	{
		id: "medium",
		name: "Medium",
		category: "Criação",
		host: "medium.com",
		build: (h) => userPath("https://medium.com/@{u}", h)
	},
	{
		id: "substack",
		name: "Substack",
		category: "Criação",
		host: "substack.com",
		hint: "Vira subdomínio. Pontos e símbolos saem.",
		build: (h) => subdomain(h, "substack.com")
	},
	{
		id: "behance",
		name: "Behance",
		category: "Criação",
		host: "behance.net",
		build: (h) => userPath("https://www.behance.net/{u}", h)
	},
	{
		id: "dribbble",
		name: "Dribbble",
		category: "Criação",
		host: "dribbble.com",
		build: (h) => userPath("https://dribbble.com/{u}", h)
	},
	{
		id: "deviantart",
		name: "DeviantArt",
		category: "Criação",
		host: "deviantart.com",
		build: (h) => userPath("https://www.deviantart.com/{u}", h)
	},
	{
		id: "artstation",
		name: "ArtStation",
		category: "Criação",
		host: "artstation.com",
		build: (h) => userPath("https://www.artstation.com/{u}", h)
	},
	{
		id: "unsplash",
		name: "Unsplash",
		category: "Criação",
		host: "unsplash.com",
		build: (h) => userPath("https://unsplash.com/@{u}", h)
	},
	{
		id: "soundcloud",
		name: "SoundCloud",
		category: "Áudio",
		host: "soundcloud.com",
		build: (h) => userPath("https://soundcloud.com/{u}", h)
	},
	{
		id: "spotify",
		name: "Spotify",
		category: "Áudio",
		host: "open.spotify.com",
		hint: "Muita conta usa um ID, não o nome de exibição.",
		build: (h) => userPath("https://open.spotify.com/user/{u}", h)
	},
	{
		id: "bandcamp",
		name: "Bandcamp",
		category: "Áudio",
		host: "bandcamp.com",
		hint: "Vira subdomínio. Pontos e símbolos saem.",
		build: (h) => subdomain(h, "bandcamp.com")
	},
	{
		id: "steam",
		name: "Steam",
		category: "Jogos",
		host: "steamcommunity.com",
		hint: "Só acha URL personalizada. ID numérico fica em /profiles/.",
		build: (h) => userPath("https://steamcommunity.com/id/{u}", h)
	},
	{
		id: "chess",
		name: "Chess.com",
		category: "Jogos",
		host: "chess.com",
		build: (h) => userPath("https://www.chess.com/member/{u}", h)
	},
	{
		id: "letterboxd",
		name: "Letterboxd",
		category: "Criação",
		host: "letterboxd.com",
		build: (h) => userPath("https://letterboxd.com/{u}/", h)
	},
	{
		id: "myanimelist",
		name: "MyAnimeList",
		category: "Jogos",
		host: "myanimelist.net",
		build: (h) => userPath("https://myanimelist.net/profile/{u}", h)
	},
	{
		id: "linktree",
		name: "Linktree",
		category: "Perfil",
		host: "linktr.ee",
		build: (h) => userPath("https://linktr.ee/{u}", h)
	},
	{
		id: "aboutme",
		name: "About.me",
		category: "Perfil",
		host: "about.me",
		build: (h) => userPath("https://about.me/{u}", h)
	},
	{
		id: "gravatar",
		name: "Gravatar",
		category: "Perfil",
		host: "gravatar.com",
		build: (h) => userPath("https://gravatar.com/{u}", h)
	},
	{
		id: "patreon",
		name: "Patreon",
		category: "Perfil",
		host: "patreon.com",
		build: (h) => userPath("https://www.patreon.com/{u}", h)
	},
	{
		id: "duolingo",
		name: "Duolingo",
		category: "Perfil",
		host: "duolingo.com",
		build: (h) => userPath("https://www.duolingo.com/profile/{u}", h)
	},
	{
		id: "wikipedia",
		name: "Wikipédia",
		category: "Perfil",
		host: "pt.wikipedia.org",
		hint: "Página de usuário na Wikipédia em português.",
		build: (h) => userPath("https://pt.wikipedia.org/wiki/User:{u}", h)
	}
];
SITES.length;
var WORK_KEY = "trilha.work.v1";
var CASES_KEY = "trilha.cases.v1";
var emptySnap = null;
function identityKey(email, handle) {
	return `${email}|${handle}`;
}
function loadJson(key, fallback) {
	if (typeof window === "undefined") return fallback;
	try {
		const raw = localStorage.getItem(key);
		return raw ? JSON.parse(raw) : fallback;
	} catch {
		return fallback;
	}
}
async function copyText(text) {
	try {
		await navigator.clipboard.writeText(text);
		return true;
	} catch {
		try {
			const area = document.createElement("textarea");
			area.value = text;
			area.setAttribute("readonly", "");
			area.style.position = "fixed";
			area.style.left = "-999px";
			document.body.appendChild(area);
			area.select();
			const ok = document.execCommand("copy");
			area.remove();
			return ok;
		} catch {
			return false;
		}
	}
}
function unquoteTxt(data) {
	const parts = data.match(/"([^"]*)"/g);
	if (!parts) return data.replace(/^"|"$/g, "");
	return parts.map((part) => part.slice(1, -1)).join("");
}
async function dnsLookup(name, type) {
	const response = await fetch(`https://dns.google/resolve?name=${encodeURIComponent(name)}&type=${type}`, { signal: AbortSignal.timeout(8e3) });
	if (!response.ok) throw new Error("dns");
	return ((await response.json()).Answer ?? []).map((row) => row.data);
}
function formatWhen(ms) {
	return new Intl.DateTimeFormat("pt-BR", {
		dateStyle: "short",
		timeStyle: "short"
	}).format(ms);
}
function TrilhaApp() {
	const [email, setEmail] = (0, import_react.useState)("");
	const [username, setUsername] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [domain, setDomain] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [more, setMore] = (0, import_react.useState)(false);
	const [formError, setFormError] = (0, import_react.useState)(null);
	const [snap, setSnap] = (0, import_react.useState)(emptySnap);
	const [tab, setTab] = (0, import_react.useState)("sinais");
	const [category, setCategory] = (0, import_react.useState)("Todas");
	const [siteQuery, setSiteQuery] = (0, import_react.useState)("");
	const [markBook, setMarkBook] = (0, import_react.useState)({});
	const [cases, setCases] = (0, import_react.useState)([]);
	const [caseLabel, setCaseLabel] = (0, import_react.useState)("");
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)("");
	const [gravatar, setGravatar] = (0, import_react.useState)("idle");
	const [github, setGithub] = (0, import_react.useState)({ status: "idle" });
	const [dns, setDns] = (0, import_react.useState)({ status: "idle" });
	(0, import_react.useEffect)(() => {
		const work = loadJson(WORK_KEY, {});
		setEmail(work.email ?? "");
		setUsername(work.username ?? "");
		setName(work.name ?? "");
		setDomain(work.domain ?? "");
		setNotes(work.notes ?? "");
		if (work.snap) setSnap({
			...work.snap,
			rawEmail: work.snap.rawEmail ?? work.email ?? "",
			rawUsername: work.snap.rawUsername ?? work.username ?? "",
			rawName: work.snap.rawName ?? work.name ?? "",
			rawDomain: work.snap.rawDomain ?? work.domain ?? ""
		});
		setMarkBook(work.markBook ?? {});
		setMore(Boolean(work.more || work.name || work.domain));
		setCases(loadJson(CASES_KEY, []));
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		localStorage.setItem(WORK_KEY, JSON.stringify({
			email,
			username,
			name,
			domain,
			notes,
			snap,
			markBook,
			more
		}));
	}, [
		hydrated,
		email,
		username,
		name,
		domain,
		notes,
		snap,
		markBook,
		more
	]);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		localStorage.setItem(CASES_KEY, JSON.stringify(cases));
	}, [hydrated, cases]);
	const key = snap ? identityKey(snap.email, snap.handle) : "";
	const marks = key ? markBook[key] ?? {} : {};
	const foundCount = Object.values(marks).filter((mark) => mark === "found").length;
	const missCount = Object.values(marks).filter((mark) => mark === "miss").length;
	const patterns = (0, import_react.useMemo)(() => {
		if (!snap?.name) return [];
		return emailPatterns(snap.name, snap.domain || void 0);
	}, [snap]);
	const searches = (0, import_react.useMemo)(() => {
		if (!snap) return [];
		return buildSearches({
			email: snap.analysis?.valid ? snap.analysis.email : "",
			username: snap.handle,
			name: snap.name,
			domain: snap.domain
		});
	}, [snap]);
	const visibleSites = (0, import_react.useMemo)(() => {
		const q = siteQuery.trim().toLowerCase();
		return SITES.filter((site) => {
			if (category !== "Todas" && site.category !== category) return false;
			if (!q) return true;
			return site.name.toLowerCase().includes(q) || site.host.toLowerCase().includes(q) || site.category.toLowerCase().includes(q);
		});
	}, [category, siteQuery]);
	(0, import_react.useEffect)(() => {
		const hash = snap?.analysis?.gravatarHash;
		if (!hash) {
			setGravatar("idle");
			return;
		}
		let cancel = false;
		setGravatar("loading");
		const img = new Image();
		img.onload = () => {
			if (!cancel) setGravatar("yes");
		};
		img.onerror = () => {
			if (!cancel) setGravatar("no");
		};
		img.src = `https://www.gravatar.com/avatar/${hash}?s=160&d=404`;
		return () => {
			cancel = true;
		};
	}, [snap?.analysis?.gravatarHash]);
	(0, import_react.useEffect)(() => {
		const handle = snap?.handle ?? "";
		if (!handle) {
			setGithub({ status: "idle" });
			return;
		}
		let cancel = false;
		setGithub({ status: "loading" });
		fetch(`https://api.github.com/users/${encodeURIComponent(handle)}`, {
			headers: { Accept: "application/vnd.github+json" },
			signal: AbortSignal.timeout(8e3)
		}).then(async (response) => {
			if (cancel) return;
			if (response.status === 404) {
				setGithub({ status: "miss" });
				return;
			}
			if (!response.ok) {
				setGithub({ status: "error" });
				return;
			}
			const user = await response.json();
			if (!user.login || !user.html_url) {
				setGithub({ status: "error" });
				return;
			}
			setGithub({
				status: "found",
				login: user.login,
				name: user.name ?? null,
				bio: user.bio ?? null,
				blog: user.blog ?? null,
				company: user.company ?? null,
				location: user.location ?? null,
				publicRepos: user.public_repos ?? 0,
				createdAt: user.created_at ?? "",
				avatar: user.avatar_url ?? "",
				url: user.html_url,
				twitter: user.twitter_username ?? null
			});
		}).catch(() => {
			if (!cancel) setGithub({ status: "error" });
		});
		return () => {
			cancel = true;
		};
	}, [snap?.handle]);
	(0, import_react.useEffect)(() => {
		const zone = snap?.domain ?? "";
		if (!zone || !isDomain(zone)) {
			setDns(snap ? { status: "skip" } : { status: "idle" });
			return;
		}
		let cancel = false;
		setDns({ status: "loading" });
		Promise.all([
			dnsLookup(zone, "MX"),
			dnsLookup(zone, "TXT"),
			dnsLookup(`_dmarc.${zone}`, "TXT")
		]).then(([mxRaw, txtRaw, dmarcRaw]) => {
			if (cancel) return;
			const mx = mxRaw.map((row) => {
				const clean = row.replace(/\.$/, "");
				const [priority, host] = clean.split(/\s+/);
				return host ? `${host.replace(/\.$/, "")} · ${priority}` : clean;
			});
			const spf = txtRaw.map(unquoteTxt).find((row) => row.toLowerCase().startsWith("v=spf1")) ?? null;
			const dmarc = dmarcRaw.map(unquoteTxt).find((row) => row.toLowerCase().startsWith("v=dmarc1")) ?? null;
			setDns({
				status: "ok",
				mx,
				spf,
				dmarc
			});
		}).catch(() => {
			if (!cancel) setDns({ status: "error" });
		});
		return () => {
			cancel = true;
		};
	}, [snap]);
	function mountFrom(next) {
		const nextUsername = next?.username ?? username;
		const analysis = email.trim() ? analyzeEmail(email) : null;
		if (email.trim() && analysis && !analysis.valid) {
			setFormError(analysis.reason ?? "E-mail inválido.");
			return;
		}
		const typedDomain = domain.trim().replace(/^@/, "").toLowerCase();
		if (typedDomain && !isDomain(typedDomain)) {
			setFormError("Domínio inválido. Use algo como empresa.com.br.");
			return;
		}
		const typedHandle = cleanHandle(nextUsername);
		const derived = analysis?.valid ? analysis.local.split("+")[0] ?? "" : "";
		const handle = typedHandle || derived;
		const resolvedDomain = typedDomain || analysis?.domain || "";
		if (!handle && !analysis?.valid && !name.trim() && !resolvedDomain) {
			setFormError("Informe um e-mail, um usuário ou um nome.");
			return;
		}
		const shownUsername = nextUsername.trim() ? nextUsername : handle;
		setFormError(null);
		setUsername(shownUsername);
		setSnap({
			email: analysis?.valid ? analysis.email : "",
			username: cleanHandle(shownUsername) || handle,
			name: name.trim(),
			domain: resolvedDomain,
			handle,
			analysis: analysis?.valid ? analysis : null,
			rawEmail: email,
			rawUsername: shownUsername,
			rawName: name,
			rawDomain: domain
		});
		setTab(analysis?.valid || name.trim() ? "sinais" : "sites");
	}
	function setMark(id, value) {
		if (!key) return;
		setMarkBook((current) => {
			const row = { ...current[key] ?? {} };
			if (row[id] === value) delete row[id];
			else row[id] = value;
			return {
				...current,
				[key]: row
			};
		});
	}
	async function onCopy(id, text) {
		const ok = await copyText(text);
		setCopied(ok ? id : "erro");
		window.setTimeout(() => setCopied(""), 1600);
	}
	function reportText() {
		if (!snap) return "";
		const lines = [
			"Trilha — dossiê de fontes públicas",
			snap.email ? `E-mail: ${snap.email}` : "E-mail: —",
			snap.handle ? `Usuário: ${snap.handle}` : "Usuário: —",
			snap.name ? `Nome: ${snap.name}` : "",
			snap.domain ? `Domínio: ${snap.domain}` : "",
			snap.analysis ? `Tipo: ${snap.analysis.kind}${snap.analysis.provider ? ` · ${snap.analysis.provider}` : ""}${snap.analysis.role ? " · caixa funcional" : ""}` : "",
			"",
			"Sites marcados como existentes:"
		];
		const hits = SITES.filter((site) => marks[site.id] === "found");
		if (hits.length === 0) lines.push("— nenhum marcado");
		for (const site of hits) {
			const href = snap.handle ? site.build(snap.handle) : null;
			lines.push(`- ${site.name}${href ? `: ${href}` : ""}`);
		}
		if (notes.trim()) lines.push("", "Notas:", notes.trim());
		lines.push("", "Gerado neste aparelho. Não confirma conta fechada nem vazamento de senha.");
		return lines.filter((line) => line !== "").join("\n");
	}
	function saveCase() {
		if (!snap) return;
		const label = caseLabel.trim() || snap.email || snap.handle || snap.name || "Caso sem título";
		const entry = {
			id: crypto.randomUUID(),
			label,
			email: snap.email,
			username: snap.username,
			name: snap.name,
			domain: snap.domain === snap.analysis?.domain && !domain.trim() ? "" : domain.trim(),
			notes,
			marks: { ...marks },
			savedAt: Date.now()
		};
		setCases((current) => [entry, ...current].slice(0, 40));
		setCaseLabel("");
		setCopied("salvo");
		window.setTimeout(() => setCopied(""), 1600);
	}
	function loadCase(entry) {
		setEmail(entry.email);
		setUsername(entry.username);
		setName(entry.name);
		setDomain(entry.domain);
		setNotes(entry.notes);
		setMore(Boolean(entry.name || entry.domain));
		const analysis = entry.email ? analyzeEmail(entry.email) : null;
		const handle = cleanHandle(entry.username) || (analysis?.valid ? analysis.local.split("+")[0] ?? "" : "");
		const resolvedDomain = entry.domain.trim().replace(/^@/, "").toLowerCase() || analysis?.domain || "";
		const next = {
			email: analysis?.valid ? analysis.email : "",
			username: cleanHandle(entry.username) || handle,
			name: entry.name,
			domain: resolvedDomain,
			handle,
			analysis: analysis?.valid ? analysis : null,
			rawEmail: entry.email,
			rawUsername: entry.username,
			rawName: entry.name,
			rawDomain: entry.domain
		};
		setSnap(next);
		setMarkBook((current) => ({
			...current,
			[identityKey(next.email, next.handle)]: entry.marks
		}));
		setFormError(null);
		setTab("sinais");
	}
	const dirty = snap !== null && (email !== snap.rawEmail || username !== snap.rawUsername || name !== snap.rawName || domain !== snap.rawDomain);
	const linkBlock = snap?.handle ? visibleSites.map((site) => {
		const href = site.build(snap.handle);
		return href ? `${site.name}: ${href}` : null;
	}).filter((line) => Boolean(line)).join("\n") : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen bg-ink text-linen",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1 bg-brass" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-5xl px-4 pt-6 pb-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-start justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-center gap-2 text-xs font-medium tracking-widest text-mist uppercase",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanSearch, {
								className: "size-4 text-brass",
								"aria-hidden": "true"
							}), "Caderno de campo"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 font-display text-5xl leading-none font-medium text-linen italic",
							children: "Trilha"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 max-w-md text-lg leading-snug text-linen",
							children: [
								"Analisa um e-mail e abre a pegada pública em ",
								SITES.length,
								" sites."
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "hidden pt-8 text-right text-sm text-mist sm:block",
						children: [
							"DNS, Gravatar e GitHub",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"ao vivo. O resto, no clique."
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-6 rounded-2xl border border-mist/25 bg-panel p-4",
					onSubmit: (event) => {
						event.preventDefault();
						mountFrom();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-2 block text-xs font-medium tracking-wide text-mist uppercase",
									children: "E-mail"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: email,
									onChange: (event) => setEmail(event.target.value),
									inputMode: "email",
									autoCapitalize: "none",
									autoCorrect: "off",
									spellCheck: false,
									autoComplete: "off",
									placeholder: "nome@empresa.com",
									className: "h-12 w-full rounded-xl border border-mist/30 bg-ink px-3 text-base text-linen outline-none placeholder:text-mist/70 focus:border-brass focus:ring-2 focus:ring-brass/40"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-2 block text-xs font-medium tracking-wide text-mist uppercase",
									children: "Usuário"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: username,
									onChange: (event) => setUsername(event.target.value),
									autoCapitalize: "none",
									autoCorrect: "off",
									spellCheck: false,
									autoComplete: "off",
									placeholder: "@publico",
									className: "h-12 w-full rounded-xl border border-mist/30 bg-ink px-3 text-base text-linen outline-none placeholder:text-mist/70 focus:border-brass focus:ring-2 focus:ring-brass/40"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-3 min-h-11 text-sm font-medium text-brass",
							onClick: () => setMore((open) => !open),
							"aria-expanded": more,
							children: more ? "Esconder nome e domínio" : "Nome e domínio, para achar e-mails"
						}),
						more ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-2 block text-xs font-medium tracking-wide text-mist uppercase",
									children: "Nome"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: name,
									onChange: (event) => setName(event.target.value),
									autoComplete: "off",
									placeholder: "Nome Sobrenome",
									className: "h-12 w-full rounded-xl border border-mist/30 bg-ink px-3 text-base text-linen outline-none placeholder:text-mist/70 focus:border-brass focus:ring-2 focus:ring-brass/40"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-2 block text-xs font-medium tracking-wide text-mist uppercase",
									children: "Domínio"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: domain,
									onChange: (event) => setDomain(event.target.value),
									autoCapitalize: "none",
									autoCorrect: "off",
									spellCheck: false,
									autoComplete: "off",
									placeholder: "empresa.com.br",
									className: "h-12 w-full rounded-xl border border-mist/30 bg-ink px-3 text-base text-linen outline-none placeholder:text-mist/70 focus:border-brass focus:ring-2 focus:ring-brass/40"
								})]
							})]
						}) : null,
						formError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-brass",
							children: formError
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "mt-4 flex min-h-12 w-full items-center justify-center rounded-xl bg-brass px-4 text-base font-medium text-brass-ink",
							children: "Montar dossiê"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-mist",
							children: "Só fontes públicas. Não baixa senha, não entra em conta e não varre os 50 sites sozinho. O caderno fica neste aparelho."
						})
					]
				}),
				!snap ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "mt-6 grid gap-3 sm:grid-cols-3",
					children: [
						[
							"01",
							"E-mail",
							"Valida a caixa, o provedor, alias, descartável e o hash do Gravatar."
						],
						[
							"02",
							"Sinais ao vivo",
							"Consulta DNS público e se o usuário existe no GitHub."
						],
						[
							"03",
							`${SITES.length} sites`,
							"Monta o link do perfil para você abrir e marcar achou ou não."
						]
					].map(([index, title, body]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-2xl border border-mist/25 bg-panel p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl text-brass italic",
								children: index
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-2 text-base font-medium",
								children: title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-mist",
								children: body
							})
						]
					}, index))
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-end justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium tracking-widest text-mist uppercase",
									children: "Dossiê"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-lg font-medium break-all",
									children: snap.email || snap.handle || snap.name
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-4 text-sm tabular-nums",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-xs tracking-wide text-mist uppercase",
										children: "Achou"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-brass",
										children: foundCount
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-xs tracking-wide text-mist uppercase",
										children: "Não"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: missCount })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-xs tracking-wide text-mist uppercase",
										children: "Sites"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: SITES.length })] })
								]
							})]
						}),
						dirty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-brass",
							children: "Os campos mudaram. Monte o dossiê de novo para atualizar."
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "sticky top-0 z-10 -mx-4 mt-4 border-b border-mist/25 bg-ink/95 px-4 backdrop-blur",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "no-scrollbar flex gap-2 overflow-x-auto py-2",
								role: "tablist",
								children: [
									["sinais", "Sinais"],
									["sites", `${SITES.length} sites`],
									["buscas", "Buscas"],
									["casos", "Casos"]
								].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									role: "tab",
									"aria-selected": tab === id,
									onClick: () => setTab(id),
									className: tab === id ? "min-h-11 shrink-0 rounded-full bg-brass px-4 text-sm font-medium text-brass-ink" : "min-h-11 shrink-0 rounded-full border border-mist/30 px-4 text-sm text-linen",
									children: label
								}, id))
							})
						}),
						tab === "sinais" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid gap-3 lg:grid-cols-2",
							children: [
								snap.analysis ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "rounded-2xl border border-mist/25 bg-panel p-4 lg:col-span-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-start gap-4",
											children: [gravatar === "yes" && snap.analysis.gravatarHash ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: `https://www.gravatar.com/avatar/${snap.analysis.gravatarHash}?s=160&d=404`,
												alt: "Foto pública do Gravatar",
												className: "size-16 rounded-full border border-mist/30"
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex size-16 items-center justify-center rounded-full border border-mist/30 font-display text-2xl text-brass italic",
												children: (snap.analysis.local[0] ?? "?").toUpperCase()
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "min-w-0",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
														className: "text-base font-medium break-all",
														children: snap.analysis.email
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "mt-1 text-sm text-mist",
														children: [snap.analysis.kind === "gratuito" ? `Provedor gratuito · ${snap.analysis.provider}` : snap.analysis.kind === "descartável" ? "E-mail descartável" : "Domínio próprio", snap.analysis.role ? " · caixa funcional" : ""]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "mt-1 text-sm text-mist",
														children: gravatar === "loading" ? "Olhando o Gravatar…" : gravatar === "yes" ? "Tem foto pública no Gravatar." : "Sem foto pública no Gravatar."
													})
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
											className: "mt-4 grid gap-3 text-sm sm:grid-cols-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
													className: "text-xs tracking-wide text-mist uppercase",
													children: "Parte local"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
													className: "mt-1 break-all",
													children: snap.analysis.local
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
													className: "text-xs tracking-wide text-mist uppercase",
													children: "Domínio"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
													className: "mt-1 break-all",
													children: snap.analysis.domain
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "sm:col-span-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
														className: "text-xs tracking-wide text-mist uppercase",
														children: "Hash Gravatar"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
														className: "mt-1 break-all text-mist",
														children: snap.analysis.gravatarHash
													})]
												})
											]
										}),
										snap.analysis.alias ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-3 text-sm text-mist",
											children: ["Alias depois do +: ", snap.analysis.alias]
										}) : null,
										snap.analysis.providerNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm text-mist",
											children: snap.analysis.providerNote
										}) : null,
										snap.analysis.suggestions.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs tracking-wide text-mist uppercase",
												children: "Usuários para testar"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "mt-2 flex flex-wrap gap-2",
												children: snap.analysis.suggestions.map((suggestion) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => mountFrom({ username: suggestion }),
													className: "min-h-11 rounded-full border border-mist/30 px-3 text-sm",
													children: suggestion
												}, suggestion))
											})]
										}) : null
									]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "rounded-2xl border border-mist/25 bg-panel p-4 lg:col-span-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-base font-medium",
										children: "Sem e-mail nesta consulta"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-sm text-mist",
										children: [
											"A análise da caixa fica de fora. Os sites usam o usuário",
											snap.handle ? ` ${snap.handle}` : "",
											"."
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "rounded-2xl border border-mist/25 bg-panel p-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-base font-medium",
											children: "DNS público"
										}),
										dns.status === "loading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm text-mist",
											children: "Consultando…"
										}) : null,
										dns.status === "skip" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm text-mist",
											children: "Informe um e-mail ou um domínio para ver MX, SPF e DMARC."
										}) : null,
										dns.status === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm text-mist",
											children: "Não deu para consultar daqui. As buscas do domínio continuam na aba Buscas."
										}) : null,
										dns.status === "ok" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-3 grid gap-3 text-sm",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs tracking-wide text-mist uppercase",
													children: "MX"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "mt-1 block break-all",
													children: dns.mx.length > 0 ? dns.mx.join(" · ") : "Sem MX público."
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs tracking-wide text-mist uppercase",
													children: "SPF"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "mt-1 block break-all",
													children: dns.spf ?? "Ausente."
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs tracking-wide text-mist uppercase",
													children: "DMARC"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "mt-1 block break-all",
													children: dns.dmarc ?? "Ausente."
												})] })
											]
										}) : null
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "rounded-2xl border border-mist/25 bg-panel p-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-base font-medium",
											children: "GitHub"
										}),
										github.status === "idle" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm text-mist",
											children: "Sem usuário para consultar."
										}) : null,
										github.status === "loading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm text-mist",
											children: "Consultando a API pública…"
										}) : null,
										github.status === "miss" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm text-mist",
											children: "Não existe um perfil público com esse usuário."
										}) : null,
										github.status === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm text-mist",
											children: "A API não respondeu. Abra o link na lista de sites."
										}) : null,
										github.status === "found" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-3 flex gap-3",
											children: [github.avatar ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: github.avatar,
												alt: "",
												className: "size-14 rounded-full border border-mist/30"
											}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "min-w-0",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "font-medium",
														children: github.name || github.login
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "text-sm text-mist",
														children: ["@", github.login]
													}),
													github.bio ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "mt-2 text-sm",
														children: github.bio
													}) : null,
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "mt-2 text-sm text-mist",
														children: [
															github.company,
															github.location,
															`${github.publicRepos} repositórios públicos`
														].filter(Boolean).join(" · ")
													}),
													github.twitter ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "mt-1 text-sm text-mist",
														children: ["X no perfil: @", github.twitter]
													}) : null,
													github.blog ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "mt-1 text-sm break-all text-mist",
														children: github.blog
													}) : null,
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
														href: github.url,
														target: "_blank",
														rel: "noreferrer",
														className: "mt-3 inline-flex min-h-11 items-center gap-1 text-sm font-medium text-brass",
														children: ["Abrir perfil", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
															className: "size-4",
															"aria-hidden": "true"
														})]
													})
												]
											})]
										}) : null
									]
								}),
								patterns.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "rounded-2xl border border-mist/25 bg-panel p-4 lg:col-span-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-base font-medium",
											children: "Candidatos de e-mail"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-sm text-mist",
											children: "Padrões para pesquisar, não caixas confirmadas. Acento foi tirado do nome."
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => onCopy("padroes", patterns.join("\n")),
											className: "inline-flex min-h-11 shrink-0 items-center gap-2 rounded-xl border border-mist/30 px-3 text-sm",
											children: [copied === "padroes" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), "Copiar"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-3 grid gap-2 text-sm sm:grid-cols-2",
										children: patterns.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
											className: "break-all rounded-xl bg-ink px-3 py-2",
											children: item
										}, item))
									})]
								}) : null
							]
						}) : null,
						tab === "sites" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-mist",
									children: snap.handle ? `Links de @${snap.handle}. Abra, veja se o perfil existe e marque.` : "Informe um usuário para montar os links. Com só o nome, use a aba Buscas."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "no-scrollbar mt-3 flex gap-2 overflow-x-auto",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
										active: category === "Todas",
										onClick: () => setCategory("Todas"),
										label: "Todas"
									}), CATEGORIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
										active: category === item,
										onClick: () => setCategory(item),
										label: item
									}, item))]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "mt-3 block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "sr-only",
										children: "Filtrar sites"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: siteQuery,
										onChange: (event) => setSiteQuery(event.target.value),
										placeholder: "Filtrar site",
										className: "h-12 w-full rounded-xl border border-mist/30 bg-panel px-3 text-base outline-none placeholder:text-mist/70 focus:border-brass"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 flex flex-wrap gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										disabled: !linkBlock,
										onClick: () => onCopy("links", linkBlock),
										className: "inline-flex min-h-11 items-center gap-2 rounded-xl border border-mist/30 px-3 text-sm disabled:opacity-40",
										children: [copied === "links" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), "Copiar links"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => onCopy("relatorio", reportText()),
										className: "inline-flex min-h-11 items-center gap-2 rounded-xl border border-mist/30 px-3 text-sm",
										children: [copied === "relatorio" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), "Copiar relatório"]
									})]
								}),
								copied === "erro" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-brass",
									children: "Não consegui copiar daqui."
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-3 grid gap-2 lg:grid-cols-2",
									children: visibleSites.map((site) => {
										const href = snap.handle ? site.build(snap.handle) : null;
										const mark = marks[site.id];
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "rounded-2xl border border-mist/25 bg-panel p-3",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-baseline justify-between gap-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
														className: "text-base font-medium",
														children: site.name
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xs text-mist",
														children: site.category
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "truncate text-sm text-mist",
													children: site.host
												}),
												site.hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-1 text-xs text-mist",
													children: site.hint
												}) : null,
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "mt-3 flex gap-2",
													children: [
														href ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
															href,
															target: "_blank",
															rel: "noreferrer",
															className: "inline-flex min-h-11 flex-1 items-center justify-center gap-1 rounded-xl bg-linen text-sm font-medium text-ink",
															children: ["Abrir", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
																className: "size-4",
																"aria-hidden": "true"
															})]
														}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "flex min-h-11 flex-1 items-center text-sm text-mist",
															children: "Esse @ não serve aqui."
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															"aria-pressed": mark === "found",
															onClick: () => setMark(site.id, "found"),
															className: mark === "found" ? "min-h-11 rounded-xl bg-brass px-3 text-sm font-medium text-brass-ink" : "min-h-11 rounded-xl border border-mist/30 px-3 text-sm",
															children: "Achou"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															"aria-pressed": mark === "miss",
															onClick: () => setMark(site.id, "miss"),
															className: mark === "miss" ? "min-h-11 rounded-xl bg-linen px-3 text-sm font-medium text-ink" : "min-h-11 rounded-xl border border-mist/30 px-3 text-sm",
															children: "Não"
														})
													]
												})
											]
										}, site.id);
									})
								}),
								visibleSites.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-sm text-mist",
									children: "Nenhum site com esse filtro."
								}) : null
							]
						}) : null,
						tab === "buscas" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 grid gap-2 lg:grid-cols-2",
							children: searches.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-mist",
								children: "Precisa de e-mail, usuário, nome ou domínio."
							}) : searches.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: item.href,
								target: "_blank",
								rel: "noreferrer",
								className: "block rounded-2xl border border-mist/25 bg-panel p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs tracking-wide text-mist uppercase",
										children: item.group
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 flex items-center justify-between gap-3 text-base font-medium",
										children: [item.title, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
											className: "size-4 shrink-0 text-brass",
											"aria-hidden": "true"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-mist",
										children: item.detail
									})
								]
							}, item.href))
						}) : null,
						tab === "casos" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mb-2 block text-xs font-medium tracking-wide text-mist uppercase",
										children: "Notas deste caso"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										value: notes,
										onChange: (event) => setNotes(event.target.value),
										rows: 4,
										placeholder: "O que você já confirmou, fonte, data.",
										className: "w-full rounded-xl border border-mist/30 bg-panel px-3 py-3 text-base outline-none placeholder:text-mist/70 focus:border-brass"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col gap-2 sm:flex-row",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: caseLabel,
										onChange: (event) => setCaseLabel(event.target.value),
										placeholder: snap.email || snap.handle || "Título do caso",
										className: "h-12 w-full rounded-xl border border-mist/30 bg-panel px-3 text-base outline-none placeholder:text-mist/70 focus:border-brass"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: saveCase,
										className: "inline-flex min-h-12 shrink-0 items-center justify-center gap-2 rounded-xl bg-brass px-4 text-sm font-medium text-brass-ink",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, {
											className: "size-4",
											"aria-hidden": "true"
										}), copied === "salvo" ? "Salvo" : "Salvar neste aparelho"]
									})]
								}),
								cases.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-mist",
									children: "Nenhum caso salvo ainda. Isso não sai deste navegador."
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "grid gap-2",
									children: cases.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "rounded-2xl border border-mist/25 bg-panel p-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-medium",
												children: entry.label
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 truncate text-sm text-mist",
												children: [
													entry.email,
													entry.username,
													formatWhen(entry.savedAt)
												].filter(Boolean).join(" · ")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-3 flex gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => loadCase(entry),
													className: "min-h-11 flex-1 rounded-xl bg-linen text-sm font-medium text-ink",
													children: "Abrir"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => setCases((current) => current.filter((item) => item.id !== entry.id)),
													className: "inline-flex min-h-11 min-w-11 items-center justify-center rounded-xl border border-mist/30",
													"aria-label": `Apagar ${entry.label}`,
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
														className: "size-4",
														"aria-hidden": "true"
													})
												})]
											})
										]
									}, entry.id))
								})
							]
						}) : null
					]
				})
			]
		})]
	});
}
function FilterChip({ active, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: active ? "min-h-11 shrink-0 rounded-full bg-linen px-3 text-sm font-medium text-ink" : "min-h-11 shrink-0 rounded-full border border-mist/30 px-3 text-sm text-linen",
		children: label
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrilhaApp, {});
}
//#endregion
export { Home as component };
