export type SearchLink = {
  group: string;
  title: string;
  detail: string;
  href: string;
};

function q(value: string): string {
  return encodeURIComponent(value);
}

export function buildSearches(input: {
  email: string;
  username: string;
  name: string;
  domain: string;
}): SearchLink[] {
  const { email, username, name, domain } = input;
  const items: SearchLink[] = [];

  if (email) {
    const exact = `"${email}"`;
    items.push(
      {
        group: "E-mail",
        title: "Google — frase exata",
        detail: "Onde esse endereço apareceu em página pública.",
        href: `https://www.google.com/search?q=${q(exact)}`,
      },
      {
        group: "E-mail",
        title: "Bing",
        detail: "Mesma frase, outro índice.",
        href: `https://www.bing.com/search?q=${q(exact)}`,
      },
      {
        group: "E-mail",
        title: "DuckDuckGo",
        detail: "Busca sem conta.",
        href: `https://duckduckgo.com/?q=${q(exact)}`,
      },
      {
        group: "E-mail",
        title: "Have I Been Pwned",
        detail: "Diz se o e-mail surgiu em vazamento conhecido. Não mostra senha.",
        href: `https://haveibeenpwned.com/account/${q(email)}`,
      },
      {
        group: "E-mail",
        title: "Pastes públicos",
        detail: "Procura o endereço em sites de colagem.",
        href: `https://www.google.com/search?q=${q(`${exact} (site:pastebin.com OR site:rentry.co OR site:ghostbin.com OR site:paste.ee)`)}`,
      },
      {
        group: "E-mail",
        title: "Código no GitHub",
        detail: "Arquivos públicos que citam o endereço.",
        href: `https://github.com/search?q=${q(exact)}&type=code`,
      },
    );
  }

  if (username) {
    const exact = `"${username}"`;
    items.push(
      {
        group: "Usuário",
        title: "Google — usuário",
        detail: "Menções públicas desse @.",
        href: `https://www.google.com/search?q=${q(exact)}`,
      },
      {
        group: "Usuário",
        title: "Redes no Google",
        detail: "Recorte nas redes mais citadas.",
        href: `https://www.google.com/search?q=${q(`${exact} (instagram OR tiktok OR twitter OR linkedin OR github OR youtube)`)}`,
      },
    );
  }

  if (name) {
    const exact = `"${name}"`;
    items.push({
      group: "Nome",
      title: "Nome + e-mail",
      detail: "Páginas que juntam o nome a um endereço.",
      href: `https://www.google.com/search?q=${q(`${exact} (email OR e-mail OR "@")`)}`,
    });
    if (domain) {
      items.push({
        group: "Nome",
        title: `Nome no ${domain}`,
        detail: "Menções do nome junto do domínio.",
        href: `https://www.google.com/search?q=${q(`${exact} "@${domain}"`)}`,
      });
    } else {
      items.push({
        group: "Nome",
        title: "Nome em provedores comuns",
        detail: "Gmail, Outlook, Hotmail e UOL.",
        href: `https://www.google.com/search?q=${q(`${exact} ("@gmail.com" OR "@hotmail.com" OR "@outlook.com" OR "@uol.com.br")`)}`,
      });
    }
    items.push({
      group: "Nome",
      title: "LinkedIn público",
      detail: "Perfis indexados. O LinkedIn pede login para ver o resto.",
      href: `https://www.google.com/search?q=${q(`${exact} site:linkedin.com/in`)}`,
    });
  }

  if (domain) {
    items.push(
      {
        group: "Domínio",
        title: "crt.sh",
        detail: "Certificados públicos emitidos para o domínio.",
        href: `https://crt.sh/?q=${q(`%.${domain}`)}`,
      },
      {
        group: "Domínio",
        title: "WHOIS",
        detail: "Registro público: titular, datas e servidores.",
        href: `https://who.is/whois/${encodeURIComponent(domain)}`,
      },
      {
        group: "Domínio",
        title: "Páginas do domínio",
        detail: "O que o Google indexou nesse host.",
        href: `https://www.google.com/search?q=${q(`site:${domain}`)}`,
      },
    );
  }

  return items;
}
