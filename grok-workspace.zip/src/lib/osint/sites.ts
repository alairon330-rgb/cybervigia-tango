export const CATEGORIES = [
  "Social",
  "Vídeo",
  "Mensagem",
  "Trabalho",
  "Código",
  "Criação",
  "Áudio",
  "Jogos",
  "Perfil",
] as const;

export type SiteCategory = (typeof CATEGORIES)[number];

export type SocialSite = {
  id: string;
  name: string;
  category: SiteCategory;
  host: string;
  hint?: string;
  build: (handle: string) => string | null;
};

function userPath(url: string, handle: string): string | null {
  if (!handle) return null;
  return url.replace("{u}", encodeURIComponent(handle));
}

function subdomain(handle: string, root: string): string | null {
  const safe = handle.toLowerCase().replace(/[^a-z0-9-]/g, "");
  if (!safe) return null;
  return `https://${safe}.${root}`;
}

export const SITES: SocialSite[] = [
  { id: "instagram", name: "Instagram", category: "Social", host: "instagram.com", build: (h) => userPath("https://www.instagram.com/{u}/", h) },
  { id: "facebook", name: "Facebook", category: "Social", host: "facebook.com", build: (h) => userPath("https://www.facebook.com/{u}", h) },
  { id: "x", name: "X", category: "Social", host: "x.com", build: (h) => userPath("https://x.com/{u}", h) },
  { id: "tiktok", name: "TikTok", category: "Social", host: "tiktok.com", build: (h) => userPath("https://www.tiktok.com/@{u}", h) },
  { id: "threads", name: "Threads", category: "Social", host: "threads.net", build: (h) => userPath("https://www.threads.net/@{u}", h) },
  {
    id: "kwai",
    name: "Kwai",
    category: "Social",
    host: "kwai.com",
    hint: "O link público do Kwai muda de vez em quando.",
    build: (h) => userPath("https://www.kwai.com/@{u}", h),
  },
  { id: "pinterest", name: "Pinterest", category: "Social", host: "pinterest.com", build: (h) => userPath("https://www.pinterest.com/{u}/", h) },
  { id: "reddit", name: "Reddit", category: "Social", host: "reddit.com", build: (h) => userPath("https://www.reddit.com/user/{u}", h) },
  { id: "snapchat", name: "Snapchat", category: "Social", host: "snapchat.com", build: (h) => userPath("https://www.snapchat.com/add/{u}", h) },
  {
    id: "tumblr",
    name: "Tumblr",
    category: "Social",
    host: "tumblr.com",
    hint: "Vira subdomínio. Pontos e símbolos saem.",
    build: (h) => subdomain(h, "tumblr.com"),
  },
  {
    id: "bluesky",
    name: "Bluesky",
    category: "Social",
    host: "bsky.app",
    hint: "Sem ponto no nome, completa com .bsky.social.",
    build: (h) => {
      if (!h) return null;
      const handle = h.includes(".") ? h : `${h}.bsky.social`;
      return `https://bsky.app/profile/${encodeURIComponent(handle)}`;
    },
  },
  {
    id: "mastodon",
    name: "Mastodon",
    category: "Social",
    host: "mastodon.social",
    hint: "Só a instância mastodon.social. Outras pedem o endereço completo.",
    build: (h) => userPath("https://mastodon.social/@{u}", h),
  },
  { id: "vk", name: "VK", category: "Social", host: "vk.com", build: (h) => userPath("https://vk.com/{u}", h) },
  { id: "quora", name: "Quora", category: "Social", host: "quora.com", build: (h) => userPath("https://www.quora.com/profile/{u}", h) },
  { id: "youtube", name: "YouTube", category: "Vídeo", host: "youtube.com", build: (h) => userPath("https://www.youtube.com/@{u}", h) },
  { id: "twitch", name: "Twitch", category: "Vídeo", host: "twitch.tv", build: (h) => userPath("https://www.twitch.tv/{u}", h) },
  { id: "kick", name: "Kick", category: "Vídeo", host: "kick.com", build: (h) => userPath("https://kick.com/{u}", h) },
  { id: "vimeo", name: "Vimeo", category: "Vídeo", host: "vimeo.com", build: (h) => userPath("https://vimeo.com/{u}", h) },
  { id: "telegram", name: "Telegram", category: "Mensagem", host: "t.me", build: (h) => userPath("https://t.me/{u}", h) },
  { id: "linkedin", name: "LinkedIn", category: "Trabalho", host: "linkedin.com", build: (h) => userPath("https://www.linkedin.com/in/{u}", h) },
  { id: "github", name: "GitHub", category: "Código", host: "github.com", build: (h) => userPath("https://github.com/{u}", h) },
  { id: "gitlab", name: "GitLab", category: "Código", host: "gitlab.com", build: (h) => userPath("https://gitlab.com/{u}", h) },
  { id: "codepen", name: "CodePen", category: "Código", host: "codepen.io", build: (h) => userPath("https://codepen.io/{u}", h) },
  { id: "replit", name: "Replit", category: "Código", host: "replit.com", build: (h) => userPath("https://replit.com/@{u}", h) },
  { id: "devto", name: "Dev.to", category: "Código", host: "dev.to", build: (h) => userPath("https://dev.to/{u}", h) },
  { id: "hackernews", name: "Hacker News", category: "Código", host: "news.ycombinator.com", build: (h) => userPath("https://news.ycombinator.com/user?id={u}", h) },
  { id: "npm", name: "npm", category: "Código", host: "npmjs.com", build: (h) => userPath("https://www.npmjs.com/~{u}", h) },
  { id: "leetcode", name: "LeetCode", category: "Código", host: "leetcode.com", build: (h) => userPath("https://leetcode.com/u/{u}", h) },
  { id: "huggingface", name: "Hugging Face", category: "Código", host: "huggingface.co", build: (h) => userPath("https://huggingface.co/{u}", h) },
  { id: "pastebin", name: "Pastebin", category: "Código", host: "pastebin.com", build: (h) => userPath("https://pastebin.com/u/{u}", h) },
  { id: "medium", name: "Medium", category: "Criação", host: "medium.com", build: (h) => userPath("https://medium.com/@{u}", h) },
  {
    id: "substack",
    name: "Substack",
    category: "Criação",
    host: "substack.com",
    hint: "Vira subdomínio. Pontos e símbolos saem.",
    build: (h) => subdomain(h, "substack.com"),
  },
  { id: "behance", name: "Behance", category: "Criação", host: "behance.net", build: (h) => userPath("https://www.behance.net/{u}", h) },
  { id: "dribbble", name: "Dribbble", category: "Criação", host: "dribbble.com", build: (h) => userPath("https://dribbble.com/{u}", h) },
  { id: "deviantart", name: "DeviantArt", category: "Criação", host: "deviantart.com", build: (h) => userPath("https://www.deviantart.com/{u}", h) },
  { id: "artstation", name: "ArtStation", category: "Criação", host: "artstation.com", build: (h) => userPath("https://www.artstation.com/{u}", h) },
  { id: "unsplash", name: "Unsplash", category: "Criação", host: "unsplash.com", build: (h) => userPath("https://unsplash.com/@{u}", h) },
  { id: "soundcloud", name: "SoundCloud", category: "Áudio", host: "soundcloud.com", build: (h) => userPath("https://soundcloud.com/{u}", h) },
  {
    id: "spotify",
    name: "Spotify",
    category: "Áudio",
    host: "open.spotify.com",
    hint: "Muita conta usa um ID, não o nome de exibição.",
    build: (h) => userPath("https://open.spotify.com/user/{u}", h),
  },
  {
    id: "bandcamp",
    name: "Bandcamp",
    category: "Áudio",
    host: "bandcamp.com",
    hint: "Vira subdomínio. Pontos e símbolos saem.",
    build: (h) => subdomain(h, "bandcamp.com"),
  },
  {
    id: "steam",
    name: "Steam",
    category: "Jogos",
    host: "steamcommunity.com",
    hint: "Só acha URL personalizada. ID numérico fica em /profiles/.",
    build: (h) => userPath("https://steamcommunity.com/id/{u}", h),
  },
  { id: "chess", name: "Chess.com", category: "Jogos", host: "chess.com", build: (h) => userPath("https://www.chess.com/member/{u}", h) },
  { id: "letterboxd", name: "Letterboxd", category: "Criação", host: "letterboxd.com", build: (h) => userPath("https://letterboxd.com/{u}/", h) },
  { id: "myanimelist", name: "MyAnimeList", category: "Jogos", host: "myanimelist.net", build: (h) => userPath("https://myanimelist.net/profile/{u}", h) },
  { id: "linktree", name: "Linktree", category: "Perfil", host: "linktr.ee", build: (h) => userPath("https://linktr.ee/{u}", h) },
  { id: "aboutme", name: "About.me", category: "Perfil", host: "about.me", build: (h) => userPath("https://about.me/{u}", h) },
  { id: "gravatar", name: "Gravatar", category: "Perfil", host: "gravatar.com", build: (h) => userPath("https://gravatar.com/{u}", h) },
  { id: "patreon", name: "Patreon", category: "Perfil", host: "patreon.com", build: (h) => userPath("https://www.patreon.com/{u}", h) },
  { id: "duolingo", name: "Duolingo", category: "Perfil", host: "duolingo.com", build: (h) => userPath("https://www.duolingo.com/profile/{u}", h) },
  {
    id: "wikipedia",
    name: "Wikipédia",
    category: "Perfil",
    host: "pt.wikipedia.org",
    hint: "Página de usuário na Wikipédia em português.",
    build: (h) => userPath("https://pt.wikipedia.org/wiki/User:{u}", h),
  },
];

export const SITE_COUNT = SITES.length;
