import { md5 } from "./md5";

const PROVIDERS: Record<string, { name: string; note: string | null }> = {
  "gmail.com": {
    name: "Google",
    note: "Pontos no nome são ignorados e o texto depois de + é um alias da mesma caixa.",
  },
  "googlemail.com": {
    name: "Google",
    note: "É o mesmo Gmail. Pontos e o alias depois de + não criam outra caixa.",
  },
  "outlook.com": { name: "Microsoft", note: "O texto depois de + costuma ser alias da mesma caixa." },
  "outlook.com.br": { name: "Microsoft", note: "O texto depois de + costuma ser alias da mesma caixa." },
  "hotmail.com": { name: "Microsoft", note: "Caixa antiga da Microsoft, hoje no Outlook." },
  "hotmail.com.br": { name: "Microsoft", note: "Caixa antiga da Microsoft, hoje no Outlook." },
  "live.com": { name: "Microsoft", note: null },
  "live.com.br": { name: "Microsoft", note: null },
  "msn.com": { name: "Microsoft", note: null },
  "yahoo.com": { name: "Yahoo", note: "O hífen depois do nome (nome-tag) pode ser um alias." },
  "yahoo.com.br": { name: "Yahoo", note: null },
  "ymail.com": { name: "Yahoo", note: null },
  "icloud.com": { name: "Apple", note: "O texto depois de + pode ser um alias do iCloud." },
  "me.com": { name: "Apple", note: null },
  "mac.com": { name: "Apple", note: null },
  "proton.me": { name: "Proton", note: "Provedor com foco em privacidade, não é e-mail descartável." },
  "protonmail.com": { name: "Proton", note: "Provedor com foco em privacidade, não é e-mail descartável." },
  "pm.me": { name: "Proton", note: null },
  "tuta.com": { name: "Tuta", note: "Provedor com foco em privacidade." },
  "tutanota.com": { name: "Tuta", note: "Provedor com foco em privacidade." },
  "aol.com": { name: "AOL", note: null },
  "zoho.com": { name: "Zoho", note: null },
  "gmx.com": { name: "GMX", note: null },
  "fastmail.com": { name: "Fastmail", note: null },
  "hey.com": { name: "HEY", note: null },
  "uol.com.br": { name: "UOL", note: null },
  "bol.com.br": { name: "BOL", note: null },
  "terra.com.br": { name: "Terra", note: null },
  "ig.com.br": { name: "iG", note: null },
  "globo.com": { name: "Globo", note: null },
  "globomail.com": { name: "Globo", note: null },
  "oi.com.br": { name: "Oi", note: null },
  "r7.com": { name: "R7", note: null },
};

const DISPOSABLE = new Set([
  "mailinator.com",
  "guerrillamail.com",
  "guerrillamail.org",
  "guerrillamail.net",
  "guerrillamailblock.com",
  "grr.la",
  "sharklasers.com",
  "10minutemail.com",
  "10minutemail.net",
  "tempmail.com",
  "temp-mail.org",
  "temp-mail.io",
  "yopmail.com",
  "yopmail.fr",
  "trashmail.com",
  "trash-mail.com",
  "dispostable.com",
  "maildrop.cc",
  "getnada.com",
  "mohmal.com",
  "emailondeck.com",
  "mintemail.com",
  "mytemp.email",
  "tempr.email",
  "discard.email",
  "mailnesia.com",
  "inboxkitten.com",
  "spamgourmet.com",
  "getairmail.com",
  "dropmail.me",
  "moakt.com",
  "tmpmail.net",
  "tmpmail.org",
  "1secmail.com",
  "1secmail.org",
  "1secmail.net",
  "fakeinbox.com",
  "mailcatch.com",
  "spam4.me",
  "tempinbox.com",
  "burnermail.io",
  "guerrillamail.biz",
  "mailnull.com",
  "trashmail.de",
  "tempmailo.com",
  "generator.email",
  "fakemail.net",
  "throwawaymail.com",
  "mailpoof.com",
  "instant-email.org",
  "emailfake.com",
  "linshi-email.com",
  "mohmal.im",
  "tmpbox.net",
  "tempm.com",
  "discardmail.com",
  "mailexpire.com",
  "spamdecoy.net",
  "gettempmail.com",
]);

const ROLES = new Set([
  "admin",
  "administrator",
  "info",
  "contact",
  "contato",
  "suporte",
  "support",
  "sales",
  "vendas",
  "noreply",
  "no-reply",
  "donotreply",
  "postmaster",
  "webmaster",
  "hostmaster",
  "abuse",
  "security",
  "seguranca",
  "billing",
  "financeiro",
  "rh",
  "hr",
  "marketing",
  "newsletter",
  "notificacao",
  "notifications",
  "hello",
  "ola",
  "oi",
  "team",
  "equipe",
  "comercial",
  "atendimento",
  "sac",
  "ouvidoria",
  "imprensa",
  "press",
  "jobs",
  "careers",
  "vagas",
]);

export type EmailAnalysis = {
  valid: boolean;
  reason: string | null;
  email: string;
  local: string;
  domain: string;
  provider: string | null;
  providerNote: string | null;
  disposable: boolean;
  role: boolean;
  kind: "inválido" | "gratuito" | "descartável" | "próprio";
  gravatarHash: string | null;
  alias: string | null;
  suggestions: string[];
};

const LOCAL_RE = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+$/;
const DOMAIN_RE = /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$/;

export function isDomain(raw: string): boolean {
  return DOMAIN_RE.test(raw.trim().toLowerCase().replace(/^@/, ""));
}

export function analyzeEmail(raw: string): EmailAnalysis | null {
  const email = raw.trim().toLowerCase();
  if (!email) return null;

  const empty: EmailAnalysis = {
    valid: false,
    reason: "Formato irreconhecível.",
    email,
    local: "",
    domain: "",
    provider: null,
    providerNote: null,
    disposable: false,
    role: false,
    kind: "inválido",
    gravatarHash: null,
    alias: null,
    suggestions: [],
  };

  const at = email.indexOf("@");
  if (at <= 0 || at !== email.lastIndexOf("@")) {
    return { ...empty, reason: "Precisa de um único @." };
  }
  const local = email.slice(0, at);
  const domain = email.slice(at + 1);
  if (!LOCAL_RE.test(local) || local.startsWith(".") || local.endsWith(".") || local.includes("..")) {
    return { ...empty, local, domain, reason: "A parte antes do @ tem caractere inválido." };
  }
  if (!DOMAIN_RE.test(domain)) {
    return { ...empty, local, domain, reason: "O domínio não parece válido." };
  }

  const provider = PROVIDERS[domain] ?? null;
  const disposable = DISPOSABLE.has(domain);
  const base = local.split("+")[0] ?? local;
  const role = ROLES.has(base);
  const alias = local.includes("+") ? local.slice(local.indexOf("+") + 1) : null;
  const kind = disposable ? "descartável" : provider ? "gratuito" : "próprio";

  return {
    valid: true,
    reason: null,
    email,
    local,
    domain,
    provider: provider?.name ?? null,
    providerNote: provider?.note ?? null,
    disposable,
    role,
    kind,
    gravatarHash: md5(email),
    alias,
    suggestions: handleSuggestions(base),
  };
}

export function handleSuggestions(base: string): string[] {
  const clean = base.toLowerCase();
  const noDots = clean.replace(/\./g, "");
  const parts = clean.split(/[._-]+/).filter(Boolean);
  const out = new Set<string>();
  if (clean) out.add(clean);
  if (noDots) out.add(noDots);
  const underscored = clean.replace(/[.\s]+/g, "_");
  const dashed = clean.replace(/[._]+/g, "-");
  if (underscored) out.add(underscored);
  if (dashed) out.add(dashed);
  if (parts.length >= 2) {
    const [a, b] = parts;
    if (a && b) {
      out.add(a + b);
      out.add(`${a}_${b}`);
      out.add(`${a}.${b}`);
      out.add(`${a[0] ?? ""}${b}`);
      out.add(`${a}${b[0] ?? ""}`);
    }
  }
  out.delete("");
  return [...out].slice(0, 8);
}

export function cleanHandle(raw: string): string {
  return raw.trim().replace(/^@+/, "").replace(/\s+/g, "");
}

export function emailPatterns(name: string, domain?: string): string[] {
  const folded = name
    .normalize("NFD")
    .replace(/\p{M}/gu, "")
    .toLowerCase()
    .replace(/[^a-z\s]/g, " ")
    .split(/\s+/)
    .filter(Boolean);
  if (folded.length === 0) return [];
  const first = folded[0] ?? "";
  const last = folded[folded.length - 1] ?? "";
  const locals: string[] = [first];
  if (folded.length > 1 && first !== last) {
    locals.push(`${first}.${last}`, `${first}${last}`, `${first}_${last}`, `${first[0] ?? ""}${last}`, last);
  }
  const explicit = domain?.trim().replace(/^@/, "").toLowerCase();
  const domains = explicit ? [explicit] : ["gmail.com", "hotmail.com", "outlook.com", "uol.com.br"];
  const out: string[] = [];
  for (const d of domains) {
    if (!DOMAIN_RE.test(d)) continue;
    for (const local of locals) {
      if (local) out.push(`${local}@${d}`);
    }
  }
  return out.slice(0, 24);
}
