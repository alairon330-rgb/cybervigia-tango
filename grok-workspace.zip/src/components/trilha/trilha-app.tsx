import { useEffect, useMemo, useState } from "react";
import { ArrowUpRight, Bookmark, Check, Copy, ScanSearch, Trash2 } from "lucide-react";
import { analyzeEmail, cleanHandle, emailPatterns, isDomain, type EmailAnalysis } from "@/lib/osint/email";
import { buildSearches } from "@/lib/osint/searches";
import { CATEGORIES, SITES, type SiteCategory } from "@/lib/osint/sites";

type Mark = "found" | "miss";
type Tab = "sinais" | "sites" | "buscas" | "casos";

type Snapshot = {
  email: string;
  username: string;
  name: string;
  domain: string;
  handle: string;
  analysis: EmailAnalysis | null;
  rawEmail: string;
  rawUsername: string;
  rawName: string;
  rawDomain: string;
};

type SavedCase = {
  id: string;
  label: string;
  email: string;
  username: string;
  name: string;
  domain: string;
  notes: string;
  marks: Record<string, Mark>;
  savedAt: number;
};

type GhState =
  | { status: "idle" | "loading" | "miss" | "error" }
  | {
      status: "found";
      login: string;
      name: string | null;
      bio: string | null;
      blog: string | null;
      company: string | null;
      location: string | null;
      publicRepos: number;
      createdAt: string;
      avatar: string;
      url: string;
      twitter: string | null;
    };

type DnsState =
  | { status: "idle" | "loading" | "skip" | "error" }
  | { status: "ok"; mx: string[]; spf: string | null; dmarc: string | null };

const WORK_KEY = "trilha.work.v1";
const CASES_KEY = "trilha.cases.v1";

const emptySnap = null;

function identityKey(email: string, handle: string): string {
  return `${email}|${handle}`;
}

function loadJson<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    try {
      const area = document.createElement("textarea");
      area.value = text;
      area.setAttribute("readonly", "");
      area.style.position = "fixed";
      area.style.left = "-999px";
      document.body.appendChild(area);
      area.select();
      const ok = document.execCommand("copy");
      area.remove();
      return ok;
    } catch {
      return false;
    }
  }
}

function unquoteTxt(data: string): string {
  const parts = data.match(/"([^"]*)"/g);
  if (!parts) return data.replace(/^"|"$/g, "");
  return parts.map((part) => part.slice(1, -1)).join("");
}

async function dnsLookup(name: string, type: string): Promise<string[]> {
  const response = await fetch(
    `https://dns.google/resolve?name=${encodeURIComponent(name)}&type=${type}`,
    { signal: AbortSignal.timeout(8000) },
  );
  if (!response.ok) throw new Error("dns");
  const body = (await response.json()) as { Answer?: { data: string }[] };
  return (body.Answer ?? []).map((row) => row.data);
}

function formatWhen(ms: number): string {
  return new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeStyle: "short" }).format(ms);
}

export function TrilhaApp() {
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [name, setName] = useState("");
  const [domain, setDomain] = useState("");
  const [notes, setNotes] = useState("");
  const [more, setMore] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [snap, setSnap] = useState<Snapshot | null>(emptySnap);
  const [tab, setTab] = useState<Tab>("sinais");
  const [category, setCategory] = useState<SiteCategory | "Todas">("Todas");
  const [siteQuery, setSiteQuery] = useState("");
  const [markBook, setMarkBook] = useState<Record<string, Record<string, Mark>>>({});
  const [cases, setCases] = useState<SavedCase[]>([]);
  const [caseLabel, setCaseLabel] = useState("");
  const [hydrated, setHydrated] = useState(false);
  const [copied, setCopied] = useState("");
  const [gravatar, setGravatar] = useState<"idle" | "loading" | "yes" | "no">("idle");
  const [github, setGithub] = useState<GhState>({ status: "idle" });
  const [dns, setDns] = useState<DnsState>({ status: "idle" });

  useEffect(() => {
    const work = loadJson<{
      email?: string;
      username?: string;
      name?: string;
      domain?: string;
      notes?: string;
      snap?: Snapshot | null;
      markBook?: Record<string, Record<string, Mark>>;
      more?: boolean;
    }>(WORK_KEY, {});
    setEmail(work.email ?? "");
    setUsername(work.username ?? "");
    setName(work.name ?? "");
    setDomain(work.domain ?? "");
    setNotes(work.notes ?? "");
    if (work.snap) {
      setSnap({
        ...work.snap,
        rawEmail: work.snap.rawEmail ?? work.email ?? "",
        rawUsername: work.snap.rawUsername ?? work.username ?? "",
        rawName: work.snap.rawName ?? work.name ?? "",
        rawDomain: work.snap.rawDomain ?? work.domain ?? "",
      });
    }
    setMarkBook(work.markBook ?? {});
    setMore(Boolean(work.more || work.name || work.domain));
    setCases(loadJson<SavedCase[]>(CASES_KEY, []));
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(
      WORK_KEY,
      JSON.stringify({ email, username, name, domain, notes, snap, markBook, more }),
    );
  }, [hydrated, email, username, name, domain, notes, snap, markBook, more]);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(CASES_KEY, JSON.stringify(cases));
  }, [hydrated, cases]);

  const key = snap ? identityKey(snap.email, snap.handle) : "";
  const marks = key ? (markBook[key] ?? {}) : {};
  const foundCount = Object.values(marks).filter((mark) => mark === "found").length;
  const missCount = Object.values(marks).filter((mark) => mark === "miss").length;

  const patterns = useMemo(() => {
    if (!snap?.name) return [];
    return emailPatterns(snap.name, snap.domain || undefined);
  }, [snap]);

  const searches = useMemo(() => {
    if (!snap) return [];
    return buildSearches({
      email: snap.analysis?.valid ? snap.analysis.email : "",
      username: snap.handle,
      name: snap.name,
      domain: snap.domain,
    });
  }, [snap]);

  const visibleSites = useMemo(() => {
    const q = siteQuery.trim().toLowerCase();
    return SITES.filter((site) => {
      if (category !== "Todas" && site.category !== category) return false;
      if (!q) return true;
      return (
        site.name.toLowerCase().includes(q) ||
        site.host.toLowerCase().includes(q) ||
        site.category.toLowerCase().includes(q)
      );
    });
  }, [category, siteQuery]);

  useEffect(() => {
    const hash = snap?.analysis?.gravatarHash;
    if (!hash) {
      setGravatar("idle");
      return;
    }
    let cancel = false;
    setGravatar("loading");
    const img = new Image();
    img.onload = () => {
      if (!cancel) setGravatar("yes");
    };
    img.onerror = () => {
      if (!cancel) setGravatar("no");
    };
    img.src = `https://www.gravatar.com/avatar/${hash}?s=160&d=404`;
    return () => {
      cancel = true;
    };
  }, [snap?.analysis?.gravatarHash]);

  useEffect(() => {
    const handle = snap?.handle ?? "";
    if (!handle) {
      setGithub({ status: "idle" });
      return;
    }
    let cancel = false;
    setGithub({ status: "loading" });
    fetch(`https://api.github.com/users/${encodeURIComponent(handle)}`, {
      headers: { Accept: "application/vnd.github+json" },
      signal: AbortSignal.timeout(8000),
    })
      .then(async (response) => {
        if (cancel) return;
        if (response.status === 404) {
          setGithub({ status: "miss" });
          return;
        }
        if (!response.ok) {
          setGithub({ status: "error" });
          return;
        }
        const user = (await response.json()) as {
          login?: string;
          name?: string | null;
          bio?: string | null;
          blog?: string | null;
          company?: string | null;
          location?: string | null;
          public_repos?: number;
          created_at?: string;
          avatar_url?: string;
          html_url?: string;
          twitter_username?: string | null;
        };
        if (!user.login || !user.html_url) {
          setGithub({ status: "error" });
          return;
        }
        setGithub({
          status: "found",
          login: user.login,
          name: user.name ?? null,
          bio: user.bio ?? null,
          blog: user.blog ?? null,
          company: user.company ?? null,
          location: user.location ?? null,
          publicRepos: user.public_repos ?? 0,
          createdAt: user.created_at ?? "",
          avatar: user.avatar_url ?? "",
          url: user.html_url,
          twitter: user.twitter_username ?? null,
        });
      })
      .catch(() => {
        if (!cancel) setGithub({ status: "error" });
      });
    return () => {
      cancel = true;
    };
  }, [snap?.handle]);

  useEffect(() => {
    const zone = snap?.domain ?? "";
    if (!zone || !isDomain(zone)) {
      setDns(snap ? { status: "skip" } : { status: "idle" });
      return;
    }
    let cancel = false;
    setDns({ status: "loading" });
    Promise.all([dnsLookup(zone, "MX"), dnsLookup(zone, "TXT"), dnsLookup(`_dmarc.${zone}`, "TXT")])
      .then(([mxRaw, txtRaw, dmarcRaw]) => {
        if (cancel) return;
        const mx = mxRaw.map((row) => {
          const clean = row.replace(/\.$/, "");
          const [priority, host] = clean.split(/\s+/);
          return host ? `${host.replace(/\.$/, "")} · ${priority}` : clean;
        });
        const spf = txtRaw.map(unquoteTxt).find((row) => row.toLowerCase().startsWith("v=spf1")) ?? null;
        const dmarc = dmarcRaw.map(unquoteTxt).find((row) => row.toLowerCase().startsWith("v=dmarc1")) ?? null;
        setDns({ status: "ok", mx, spf, dmarc });
      })
      .catch(() => {
        if (!cancel) setDns({ status: "error" });
      });
    return () => {
      cancel = true;
    };
  }, [snap]);

  function mountFrom(next?: { username?: string }) {
    const nextUsername = next?.username ?? username;
    const analysis = email.trim() ? analyzeEmail(email) : null;
    if (email.trim() && analysis && !analysis.valid) {
      setFormError(analysis.reason ?? "E-mail inválido.");
      return;
    }
    const typedDomain = domain.trim().replace(/^@/, "").toLowerCase();
    if (typedDomain && !isDomain(typedDomain)) {
      setFormError("Domínio inválido. Use algo como empresa.com.br.");
      return;
    }
    const typedHandle = cleanHandle(nextUsername);
    const derived = analysis?.valid ? (analysis.local.split("+")[0] ?? "") : "";
    const handle = typedHandle || derived;
    const resolvedDomain = typedDomain || analysis?.domain || "";
    if (!handle && !analysis?.valid && !name.trim() && !resolvedDomain) {
      setFormError("Informe um e-mail, um usuário ou um nome.");
      return;
    }
    const shownUsername = nextUsername.trim() ? nextUsername : handle;
    setFormError(null);
    setUsername(shownUsername);
    setSnap({
      email: analysis?.valid ? analysis.email : "",
      username: cleanHandle(shownUsername) || handle,
      name: name.trim(),
      domain: resolvedDomain,
      handle,
      analysis: analysis?.valid ? analysis : null,
      rawEmail: email,
      rawUsername: shownUsername,
      rawName: name,
      rawDomain: domain,
    });
    setTab(analysis?.valid || name.trim() ? "sinais" : "sites");
  }

  function setMark(id: string, value: Mark) {
    if (!key) return;
    setMarkBook((current) => {
      const row = { ...(current[key] ?? {}) };
      if (row[id] === value) delete row[id];
      else row[id] = value;
      return { ...current, [key]: row };
    });
  }

  async function onCopy(id: string, text: string) {
    const ok = await copyText(text);
    setCopied(ok ? id : "erro");
    window.setTimeout(() => setCopied(""), 1600);
  }

  function reportText(): string {
    if (!snap) return "";
    const lines = [
      "Trilha — dossiê de fontes públicas",
      snap.email ? `E-mail: ${snap.email}` : "E-mail: —",
      snap.handle ? `Usuário: ${snap.handle}` : "Usuário: —",
      snap.name ? `Nome: ${snap.name}` : "",
      snap.domain ? `Domínio: ${snap.domain}` : "",
      snap.analysis
        ? `Tipo: ${snap.analysis.kind}${snap.analysis.provider ? ` · ${snap.analysis.provider}` : ""}${snap.analysis.role ? " · caixa funcional" : ""}`
        : "",
      "",
      "Sites marcados como existentes:",
    ];
    const hits = SITES.filter((site) => marks[site.id] === "found");
    if (hits.length === 0) lines.push("— nenhum marcado");
    for (const site of hits) {
      const href = snap.handle ? site.build(snap.handle) : null;
      lines.push(`- ${site.name}${href ? `: ${href}` : ""}`);
    }
    if (notes.trim()) {
      lines.push("", "Notas:", notes.trim());
    }
    lines.push("", "Gerado neste aparelho. Não confirma conta fechada nem vazamento de senha.");
    return lines.filter((line) => line !== "").join("\n");
  }

  function saveCase() {
    if (!snap) return;
    const label = caseLabel.trim() || snap.email || snap.handle || snap.name || "Caso sem título";
    const entry: SavedCase = {
      id: crypto.randomUUID(),
      label,
      email: snap.email,
      username: snap.username,
      name: snap.name,
      domain: snap.domain === snap.analysis?.domain && !domain.trim() ? "" : domain.trim(),
      notes,
      marks: { ...marks },
      savedAt: Date.now(),
    };
    setCases((current) => [entry, ...current].slice(0, 40));
    setCaseLabel("");
    setCopied("salvo");
    window.setTimeout(() => setCopied(""), 1600);
  }

  function loadCase(entry: SavedCase) {
    setEmail(entry.email);
    setUsername(entry.username);
    setName(entry.name);
    setDomain(entry.domain);
    setNotes(entry.notes);
    setMore(Boolean(entry.name || entry.domain));
    const analysis = entry.email ? analyzeEmail(entry.email) : null;
    const handle = cleanHandle(entry.username) || (analysis?.valid ? (analysis.local.split("+")[0] ?? "") : "");
    const resolvedDomain = entry.domain.trim().replace(/^@/, "").toLowerCase() || analysis?.domain || "";
    const next: Snapshot = {
      email: analysis?.valid ? analysis.email : "",
      username: cleanHandle(entry.username) || handle,
      name: entry.name,
      domain: resolvedDomain,
      handle,
      analysis: analysis?.valid ? analysis : null,
      rawEmail: entry.email,
      rawUsername: entry.username,
      rawName: entry.name,
      rawDomain: entry.domain,
    };
    setSnap(next);
    setMarkBook((current) => ({ ...current, [identityKey(next.email, next.handle)]: entry.marks }));
    setFormError(null);
    setTab("sinais");
  }

  const dirty =
    snap !== null &&
    (email !== snap.rawEmail ||
      username !== snap.rawUsername ||
      name !== snap.rawName ||
      domain !== snap.rawDomain);

  const linkBlock = snap?.handle
    ? visibleSites
        .map((site) => {
          const href = site.build(snap.handle);
          return href ? `${site.name}: ${href}` : null;
        })
        .filter((line): line is string => Boolean(line))
        .join("\n")
    : "";

  return (
    <main className="min-h-screen bg-ink text-linen">
      <div className="h-1 bg-brass" />
      <div className="mx-auto w-full max-w-5xl px-4 pt-6 pb-16">
        <header className="flex items-start justify-between gap-4">
          <div>
            <p className="flex items-center gap-2 text-xs font-medium tracking-widest text-mist uppercase">
              <ScanSearch className="size-4 text-brass" aria-hidden="true" />
              Caderno de campo
            </p>
            <h1 className="mt-2 font-display text-5xl leading-none font-medium text-linen italic">Trilha</h1>
            <p className="mt-3 max-w-md text-lg leading-snug text-linen">
              Analisa um e-mail e abre a pegada pública em {SITES.length} sites.
            </p>
          </div>
          <p className="hidden pt-8 text-right text-sm text-mist sm:block">
            DNS, Gravatar e GitHub
            <br />
            ao vivo. O resto, no clique.
          </p>
        </header>

        <form
          className="mt-6 rounded-2xl border border-mist/25 bg-panel p-4"
          onSubmit={(event) => {
            event.preventDefault();
            mountFrom();
          }}
        >
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="block">
              <span className="mb-2 block text-xs font-medium tracking-wide text-mist uppercase">E-mail</span>
              <input
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                inputMode="email"
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                autoComplete="off"
                placeholder="nome@empresa.com"
                className="h-12 w-full rounded-xl border border-mist/30 bg-ink px-3 text-base text-linen outline-none placeholder:text-mist/70 focus:border-brass focus:ring-2 focus:ring-brass/40"
              />
            </label>
            <label className="block">
              <span className="mb-2 block text-xs font-medium tracking-wide text-mist uppercase">Usuário</span>
              <input
                value={username}
                onChange={(event) => setUsername(event.target.value)}
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                autoComplete="off"
                placeholder="@publico"
                className="h-12 w-full rounded-xl border border-mist/30 bg-ink px-3 text-base text-linen outline-none placeholder:text-mist/70 focus:border-brass focus:ring-2 focus:ring-brass/40"
              />
            </label>
          </div>

          <button
            type="button"
            className="mt-3 min-h-11 text-sm font-medium text-brass"
            onClick={() => setMore((open) => !open)}
            aria-expanded={more}
          >
            {more ? "Esconder nome e domínio" : "Nome e domínio, para achar e-mails"}
          </button>

          {more ? (
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <label className="block">
                <span className="mb-2 block text-xs font-medium tracking-wide text-mist uppercase">Nome</span>
                <input
                  value={name}
                  onChange={(event) => setName(event.target.value)}
                  autoComplete="off"
                  placeholder="Nome Sobrenome"
                  className="h-12 w-full rounded-xl border border-mist/30 bg-ink px-3 text-base text-linen outline-none placeholder:text-mist/70 focus:border-brass focus:ring-2 focus:ring-brass/40"
                />
              </label>
              <label className="block">
                <span className="mb-2 block text-xs font-medium tracking-wide text-mist uppercase">Domínio</span>
                <input
                  value={domain}
                  onChange={(event) => setDomain(event.target.value)}
                  autoCapitalize="none"
                  autoCorrect="off"
                  spellCheck={false}
                  autoComplete="off"
                  placeholder="empresa.com.br"
                  className="h-12 w-full rounded-xl border border-mist/30 bg-ink px-3 text-base text-linen outline-none placeholder:text-mist/70 focus:border-brass focus:ring-2 focus:ring-brass/40"
                />
              </label>
            </div>
          ) : null}

          {formError ? <p className="mt-3 text-sm text-brass">{formError}</p> : null}

          <button
            type="submit"
            className="mt-4 flex min-h-12 w-full items-center justify-center rounded-xl bg-brass px-4 text-base font-medium text-brass-ink"
          >
            Montar dossiê
          </button>
          <p className="mt-3 text-sm text-mist">
            Só fontes públicas. Não baixa senha, não entra em conta e não varre os 50 sites sozinho.
            O caderno fica neste aparelho.
          </p>
        </form>

        {!snap ? (
          <section className="mt-6 grid gap-3 sm:grid-cols-3">
            {[
              ["01", "E-mail", "Valida a caixa, o provedor, alias, descartável e o hash do Gravatar."],
              ["02", "Sinais ao vivo", "Consulta DNS público e se o usuário existe no GitHub."],
              ["03", `${SITES.length} sites`, "Monta o link do perfil para você abrir e marcar achou ou não."],
            ].map(([index, title, body]) => (
              <article key={index} className="rounded-2xl border border-mist/25 bg-panel p-4">
                <p className="font-display text-2xl text-brass italic">{index}</p>
                <h2 className="mt-2 text-base font-medium">{title}</h2>
                <p className="mt-1 text-sm text-mist">{body}</p>
              </article>
            ))}
          </section>
        ) : (
          <section className="mt-6">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div className="min-w-0">
                <p className="text-xs font-medium tracking-widest text-mist uppercase">Dossiê</p>
                <p className="truncate text-lg font-medium break-all">
                  {snap.email || snap.handle || snap.name}
                </p>
              </div>
              <div className="flex gap-4 text-sm tabular-nums">
                <p>
                  <span className="block text-xs tracking-wide text-mist uppercase">Achou</span>
                  <span className="text-brass">{foundCount}</span>
                </p>
                <p>
                  <span className="block text-xs tracking-wide text-mist uppercase">Não</span>
                  <span>{missCount}</span>
                </p>
                <p>
                  <span className="block text-xs tracking-wide text-mist uppercase">Sites</span>
                  <span>{SITES.length}</span>
                </p>
              </div>
            </div>
            {dirty ? (
              <p className="mt-2 text-sm text-brass">Os campos mudaram. Monte o dossiê de novo para atualizar.</p>
            ) : null}

            <div className="sticky top-0 z-10 -mx-4 mt-4 border-b border-mist/25 bg-ink/95 px-4 backdrop-blur">
              <div className="no-scrollbar flex gap-2 overflow-x-auto py-2" role="tablist">
                {(
                  [
                    ["sinais", "Sinais"],
                    ["sites", `${SITES.length} sites`],
                    ["buscas", "Buscas"],
                    ["casos", "Casos"],
                  ] as const
                ).map(([id, label]) => (
                  <button
                    key={id}
                    type="button"
                    role="tab"
                    aria-selected={tab === id}
                    onClick={() => setTab(id)}
                    className={
                      tab === id
                        ? "min-h-11 shrink-0 rounded-full bg-brass px-4 text-sm font-medium text-brass-ink"
                        : "min-h-11 shrink-0 rounded-full border border-mist/30 px-4 text-sm text-linen"
                    }
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {tab === "sinais" ? (
              <div className="mt-4 grid gap-3 lg:grid-cols-2">
                {snap.analysis ? (
                  <article className="rounded-2xl border border-mist/25 bg-panel p-4 lg:col-span-2">
                    <div className="flex items-start gap-4">
                      {gravatar === "yes" && snap.analysis.gravatarHash ? (
                        <img
                          src={`https://www.gravatar.com/avatar/${snap.analysis.gravatarHash}?s=160&d=404`}
                          alt="Foto pública do Gravatar"
                          className="size-16 rounded-full border border-mist/30"
                        />
                      ) : (
                        <div className="flex size-16 items-center justify-center rounded-full border border-mist/30 font-display text-2xl text-brass italic">
                          {(snap.analysis.local[0] ?? "?").toUpperCase()}
                        </div>
                      )}
                      <div className="min-w-0">
                        <h2 className="text-base font-medium break-all">{snap.analysis.email}</h2>
                        <p className="mt-1 text-sm text-mist">
                          {snap.analysis.kind === "gratuito"
                            ? `Provedor gratuito · ${snap.analysis.provider}`
                            : snap.analysis.kind === "descartável"
                              ? "E-mail descartável"
                              : "Domínio próprio"}
                          {snap.analysis.role ? " · caixa funcional" : ""}
                        </p>
                        <p className="mt-1 text-sm text-mist">
                          {gravatar === "loading"
                            ? "Olhando o Gravatar…"
                            : gravatar === "yes"
                              ? "Tem foto pública no Gravatar."
                              : "Sem foto pública no Gravatar."}
                        </p>
                      </div>
                    </div>
                    <dl className="mt-4 grid gap-3 text-sm sm:grid-cols-2">
                      <div>
                        <dt className="text-xs tracking-wide text-mist uppercase">Parte local</dt>
                        <dd className="mt-1 break-all">{snap.analysis.local}</dd>
                      </div>
                      <div>
                        <dt className="text-xs tracking-wide text-mist uppercase">Domínio</dt>
                        <dd className="mt-1 break-all">{snap.analysis.domain}</dd>
                      </div>
                      <div className="sm:col-span-2">
                        <dt className="text-xs tracking-wide text-mist uppercase">Hash Gravatar</dt>
                        <dd className="mt-1 break-all text-mist">{snap.analysis.gravatarHash}</dd>
                      </div>
                    </dl>
                    {snap.analysis.alias ? (
                      <p className="mt-3 text-sm text-mist">Alias depois do +: {snap.analysis.alias}</p>
                    ) : null}
                    {snap.analysis.providerNote ? (
                      <p className="mt-2 text-sm text-mist">{snap.analysis.providerNote}</p>
                    ) : null}
                    {snap.analysis.suggestions.length > 0 ? (
                      <div className="mt-4">
                        <p className="text-xs tracking-wide text-mist uppercase">Usuários para testar</p>
                        <div className="mt-2 flex flex-wrap gap-2">
                          {snap.analysis.suggestions.map((suggestion) => (
                            <button
                              key={suggestion}
                              type="button"
                              onClick={() => mountFrom({ username: suggestion })}
                              className="min-h-11 rounded-full border border-mist/30 px-3 text-sm"
                            >
                              {suggestion}
                            </button>
                          ))}
                        </div>
                      </div>
                    ) : null}
                  </article>
                ) : (
                  <article className="rounded-2xl border border-mist/25 bg-panel p-4 lg:col-span-2">
                    <h2 className="text-base font-medium">Sem e-mail nesta consulta</h2>
                    <p className="mt-1 text-sm text-mist">
                      A análise da caixa fica de fora. Os sites usam o usuário
                      {snap.handle ? ` ${snap.handle}` : ""}.
                    </p>
                  </article>
                )}

                <article className="rounded-2xl border border-mist/25 bg-panel p-4">
                  <h2 className="text-base font-medium">DNS público</h2>
                  {dns.status === "loading" ? <p className="mt-2 text-sm text-mist">Consultando…</p> : null}
                  {dns.status === "skip" ? (
                    <p className="mt-2 text-sm text-mist">Informe um e-mail ou um domínio para ver MX, SPF e DMARC.</p>
                  ) : null}
                  {dns.status === "error" ? (
                    <p className="mt-2 text-sm text-mist">Não deu para consultar daqui. As buscas do domínio continuam na aba Buscas.</p>
                  ) : null}
                  {dns.status === "ok" ? (
                    <div className="mt-3 grid gap-3 text-sm">
                      <p>
                        <span className="text-xs tracking-wide text-mist uppercase">MX</span>
                        <span className="mt-1 block break-all">
                          {dns.mx.length > 0 ? dns.mx.join(" · ") : "Sem MX público."}
                        </span>
                      </p>
                      <p>
                        <span className="text-xs tracking-wide text-mist uppercase">SPF</span>
                        <span className="mt-1 block break-all">{dns.spf ?? "Ausente."}</span>
                      </p>
                      <p>
                        <span className="text-xs tracking-wide text-mist uppercase">DMARC</span>
                        <span className="mt-1 block break-all">{dns.dmarc ?? "Ausente."}</span>
                      </p>
                    </div>
                  ) : null}
                </article>

                <article className="rounded-2xl border border-mist/25 bg-panel p-4">
                  <h2 className="text-base font-medium">GitHub</h2>
                  {github.status === "idle" ? (
                    <p className="mt-2 text-sm text-mist">Sem usuário para consultar.</p>
                  ) : null}
                  {github.status === "loading" ? <p className="mt-2 text-sm text-mist">Consultando a API pública…</p> : null}
                  {github.status === "miss" ? (
                    <p className="mt-2 text-sm text-mist">Não existe um perfil público com esse usuário.</p>
                  ) : null}
                  {github.status === "error" ? (
                    <p className="mt-2 text-sm text-mist">A API não respondeu. Abra o link na lista de sites.</p>
                  ) : null}
                  {github.status === "found" ? (
                    <div className="mt-3 flex gap-3">
                      {github.avatar ? (
                        <img src={github.avatar} alt="" className="size-14 rounded-full border border-mist/30" />
                      ) : null}
                      <div className="min-w-0">
                        <p className="font-medium">{github.name || github.login}</p>
                        <p className="text-sm text-mist">@{github.login}</p>
                        {github.bio ? <p className="mt-2 text-sm">{github.bio}</p> : null}
                        <p className="mt-2 text-sm text-mist">
                          {[github.company, github.location, `${github.publicRepos} repositórios públicos`]
                            .filter(Boolean)
                            .join(" · ")}
                        </p>
                        {github.twitter ? <p className="mt-1 text-sm text-mist">X no perfil: @{github.twitter}</p> : null}
                        {github.blog ? <p className="mt-1 text-sm break-all text-mist">{github.blog}</p> : null}
                        <a
                          href={github.url}
                          target="_blank"
                          rel="noreferrer"
                          className="mt-3 inline-flex min-h-11 items-center gap-1 text-sm font-medium text-brass"
                        >
                          Abrir perfil
                          <ArrowUpRight className="size-4" aria-hidden="true" />
                        </a>
                      </div>
                    </div>
                  ) : null}
                </article>

                {patterns.length > 0 ? (
                  <article className="rounded-2xl border border-mist/25 bg-panel p-4 lg:col-span-2">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h2 className="text-base font-medium">Candidatos de e-mail</h2>
                        <p className="mt-1 text-sm text-mist">
                          Padrões para pesquisar, não caixas confirmadas. Acento foi tirado do nome.
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => onCopy("padroes", patterns.join("\n"))}
                        className="inline-flex min-h-11 shrink-0 items-center gap-2 rounded-xl border border-mist/30 px-3 text-sm"
                      >
                        {copied === "padroes" ? <Check className="size-4" /> : <Copy className="size-4" />}
                        Copiar
                      </button>
                    </div>
                    <ul className="mt-3 grid gap-2 text-sm sm:grid-cols-2">
                      {patterns.map((item) => (
                        <li key={item} className="break-all rounded-xl bg-ink px-3 py-2">
                          {item}
                        </li>
                      ))}
                    </ul>
                  </article>
                ) : null}
              </div>
            ) : null}

            {tab === "sites" ? (
              <div className="mt-4">
                <p className="text-sm text-mist">
                  {snap.handle
                    ? `Links de @${snap.handle}. Abra, veja se o perfil existe e marque.`
                    : "Informe um usuário para montar os links. Com só o nome, use a aba Buscas."}
                </p>
                <div className="no-scrollbar mt-3 flex gap-2 overflow-x-auto">
                  <FilterChip active={category === "Todas"} onClick={() => setCategory("Todas")} label="Todas" />
                  {CATEGORIES.map((item) => (
                    <FilterChip
                      key={item}
                      active={category === item}
                      onClick={() => setCategory(item)}
                      label={item}
                    />
                  ))}
                </div>
                <label className="mt-3 block">
                  <span className="sr-only">Filtrar sites</span>
                  <input
                    value={siteQuery}
                    onChange={(event) => setSiteQuery(event.target.value)}
                    placeholder="Filtrar site"
                    className="h-12 w-full rounded-xl border border-mist/30 bg-panel px-3 text-base outline-none placeholder:text-mist/70 focus:border-brass"
                  />
                </label>
                <div className="mt-3 flex flex-wrap gap-2">
                  <button
                    type="button"
                    disabled={!linkBlock}
                    onClick={() => onCopy("links", linkBlock)}
                    className="inline-flex min-h-11 items-center gap-2 rounded-xl border border-mist/30 px-3 text-sm disabled:opacity-40"
                  >
                    {copied === "links" ? <Check className="size-4" /> : <Copy className="size-4" />}
                    Copiar links
                  </button>
                  <button
                    type="button"
                    onClick={() => onCopy("relatorio", reportText())}
                    className="inline-flex min-h-11 items-center gap-2 rounded-xl border border-mist/30 px-3 text-sm"
                  >
                    {copied === "relatorio" ? <Check className="size-4" /> : <Copy className="size-4" />}
                    Copiar relatório
                  </button>
                </div>
                {copied === "erro" ? <p className="mt-2 text-sm text-brass">Não consegui copiar daqui.</p> : null}
                <ul className="mt-3 grid gap-2 lg:grid-cols-2">
                  {visibleSites.map((site) => {
                    const href = snap.handle ? site.build(snap.handle) : null;
                    const mark = marks[site.id];
                    return (
                      <li key={site.id} className="rounded-2xl border border-mist/25 bg-panel p-3">
                        <div className="flex items-baseline justify-between gap-3">
                          <h3 className="text-base font-medium">{site.name}</h3>
                          <span className="text-xs text-mist">{site.category}</span>
                        </div>
                        <p className="truncate text-sm text-mist">{site.host}</p>
                        {site.hint ? <p className="mt-1 text-xs text-mist">{site.hint}</p> : null}
                        <div className="mt-3 flex gap-2">
                          {href ? (
                            <a
                              href={href}
                              target="_blank"
                              rel="noreferrer"
                              className="inline-flex min-h-11 flex-1 items-center justify-center gap-1 rounded-xl bg-linen text-sm font-medium text-ink"
                            >
                              Abrir
                              <ArrowUpRight className="size-4" aria-hidden="true" />
                            </a>
                          ) : (
                            <p className="flex min-h-11 flex-1 items-center text-sm text-mist">Esse @ não serve aqui.</p>
                          )}
                          <button
                            type="button"
                            aria-pressed={mark === "found"}
                            onClick={() => setMark(site.id, "found")}
                            className={
                              mark === "found"
                                ? "min-h-11 rounded-xl bg-brass px-3 text-sm font-medium text-brass-ink"
                                : "min-h-11 rounded-xl border border-mist/30 px-3 text-sm"
                            }
                          >
                            Achou
                          </button>
                          <button
                            type="button"
                            aria-pressed={mark === "miss"}
                            onClick={() => setMark(site.id, "miss")}
                            className={
                              mark === "miss"
                                ? "min-h-11 rounded-xl bg-linen px-3 text-sm font-medium text-ink"
                                : "min-h-11 rounded-xl border border-mist/30 px-3 text-sm"
                            }
                          >
                            Não
                          </button>
                        </div>
                      </li>
                    );
                  })}
                </ul>
                {visibleSites.length === 0 ? <p className="mt-4 text-sm text-mist">Nenhum site com esse filtro.</p> : null}
              </div>
            ) : null}

            {tab === "buscas" ? (
              <div className="mt-4 grid gap-2 lg:grid-cols-2">
                {searches.length === 0 ? (
                  <p className="text-sm text-mist">Precisa de e-mail, usuário, nome ou domínio.</p>
                ) : (
                  searches.map((item) => (
                    <a
                      key={item.href}
                      href={item.href}
                      target="_blank"
                      rel="noreferrer"
                      className="block rounded-2xl border border-mist/25 bg-panel p-4"
                    >
                      <p className="text-xs tracking-wide text-mist uppercase">{item.group}</p>
                      <p className="mt-1 flex items-center justify-between gap-3 text-base font-medium">
                        {item.title}
                        <ArrowUpRight className="size-4 shrink-0 text-brass" aria-hidden="true" />
                      </p>
                      <p className="mt-1 text-sm text-mist">{item.detail}</p>
                    </a>
                  ))
                )}
              </div>
            ) : null}

            {tab === "casos" ? (
              <div className="mt-4 grid gap-3">
                <label className="block">
                  <span className="mb-2 block text-xs font-medium tracking-wide text-mist uppercase">Notas deste caso</span>
                  <textarea
                    value={notes}
                    onChange={(event) => setNotes(event.target.value)}
                    rows={4}
                    placeholder="O que você já confirmou, fonte, data."
                    className="w-full rounded-xl border border-mist/30 bg-panel px-3 py-3 text-base outline-none placeholder:text-mist/70 focus:border-brass"
                  />
                </label>
                <div className="flex flex-col gap-2 sm:flex-row">
                  <input
                    value={caseLabel}
                    onChange={(event) => setCaseLabel(event.target.value)}
                    placeholder={snap.email || snap.handle || "Título do caso"}
                    className="h-12 w-full rounded-xl border border-mist/30 bg-panel px-3 text-base outline-none placeholder:text-mist/70 focus:border-brass"
                  />
                  <button
                    type="button"
                    onClick={saveCase}
                    className="inline-flex min-h-12 shrink-0 items-center justify-center gap-2 rounded-xl bg-brass px-4 text-sm font-medium text-brass-ink"
                  >
                    <Bookmark className="size-4" aria-hidden="true" />
                    {copied === "salvo" ? "Salvo" : "Salvar neste aparelho"}
                  </button>
                </div>
                {cases.length === 0 ? (
                  <p className="text-sm text-mist">Nenhum caso salvo ainda. Isso não sai deste navegador.</p>
                ) : (
                  <ul className="grid gap-2">
                    {cases.map((entry) => (
                      <li key={entry.id} className="rounded-2xl border border-mist/25 bg-panel p-3">
                        <p className="font-medium">{entry.label}</p>
                        <p className="mt-1 truncate text-sm text-mist">
                          {[entry.email, entry.username, formatWhen(entry.savedAt)].filter(Boolean).join(" · ")}
                        </p>
                        <div className="mt-3 flex gap-2">
                          <button
                            type="button"
                            onClick={() => loadCase(entry)}
                            className="min-h-11 flex-1 rounded-xl bg-linen text-sm font-medium text-ink"
                          >
                            Abrir
                          </button>
                          <button
                            type="button"
                            onClick={() => setCases((current) => current.filter((item) => item.id !== entry.id))}
                            className="inline-flex min-h-11 min-w-11 items-center justify-center rounded-xl border border-mist/30"
                            aria-label={`Apagar ${entry.label}`}
                          >
                            <Trash2 className="size-4" aria-hidden="true" />
                          </button>
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ) : null}
          </section>
        )}
      </div>
    </main>
  );
}

function FilterChip({
  active,
  label,
  onClick,
}: {
  active: boolean;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={
        active
          ? "min-h-11 shrink-0 rounded-full bg-linen px-3 text-sm font-medium text-ink"
          : "min-h-11 shrink-0 rounded-full border border-mist/30 px-3 text-sm text-linen"
      }
    >
      {label}
    </button>
  );
}
