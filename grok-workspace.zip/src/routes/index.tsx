import { createFileRoute } from "@tanstack/react-router";
import { TrilhaApp } from "@/components/trilha/trilha-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <TrilhaApp />;
}
